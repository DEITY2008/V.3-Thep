/*
 * THEP 4WD Controller — ESP32 firmware v2.0
 * ------------------------------------------------------------
 *  - ควบคุมมอเตอร์ 4 ตัว (L298N x2) แบบ "ทีละล้อ" ด้วย PWM ที่ขา IN
 *    (ไม่ต้องแกะจั๊มเปอร์ ENA/ENB ออก ใช้สายเดิมตามรูปได้เลย)
 *  - ผสมสัญญาณแบบ arcade/tank: เลี้ยวอยู่กับที่ได้ ขับตรงได้ มี Trim ชดเชยซ้าย/ขวา
 *  - ปรับความนุ่ม (ramp), แรงเริ่มหมุนขั้นต่ำ, เบรกค้าง, Turbo
 *  - Failsafe: ไม่ได้รับคำสั่งเกิน 400 ms หรือหลุดการเชื่อมต่อ = หยุดทันที
 *  - เชื่อมต่อ 2 ทาง:
 *      1) WiFi AP  "THEP-4WD" (รหัส 12345678)  เปิด http://192.168.4.1  (ใช้ได้ทุกมือถือ)
 *      2) Bluetooth LE (Nordic UART)  ชื่ออุปกรณ์ "THEP-4WD"
 *
 *  ไลบรารีที่ต้องติดตั้ง (Library Manager):  "WebSockets" by Markus Sattler
 *  Board: ESP32 Dev Module     Partition Scheme: "Huge APP (3MB No OTA/1MB SPIFFS)"
 *  รองรับ ESP32 Arduino core 2.x และ 3.x
 *
 *  ขา (ตามที่ใช้งานจริง)
 *    ซ้าย L298N : IN1=18  IN2=19  IN3=21  IN4=22
 *    ขวา L298N  : IN1=33  IN2=32  IN3=26  IN4=27
 */

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <WebSocketsServer.h>

#define ENABLE_BLE 1          // ตั้งเป็น 0 ถ้าไม่ต้องการ Bluetooth
#if ENABLE_BLE
  #include <BLEDevice.h>
  #include <BLEServer.h>
  #include <BLEUtils.h>
  #include <BLE2902.h>
#endif

#ifndef ESP_ARDUINO_VERSION_MAJOR
  #define ESP_ARDUINO_VERSION_MAJOR 2
#endif

// ---------------- ตั้งค่า WiFi / ชื่อ ----------------
static const char* AP_SSID = "THEP-4WD";
static const char* AP_PASS = "12345678";      // อย่างน้อย 8 ตัวอักษร
static const char* BLE_NAME = "THEP-4WD";

// ---------------- ขามอเตอร์ ----------------
// ช่อง (channel) 0..3 = คู่ขา IN ของ L298N แต่ละฝั่ง/แต่ละวงจร
//   ch0 = ซ้าย IN1/IN2 (OUT1/OUT2)   ch1 = ซ้าย IN3/IN4 (OUT3/OUT4)
//   ch2 = ขวา IN1/IN2 (OUT1/OUT2)    ch3 = ขวา IN3/IN4 (OUT3/OUT4)
static const uint8_t PIN_A[4] = {18, 21, 33, 26};
static const uint8_t PIN_B[4] = {19, 22, 32, 27};

#define PWM_FREQ 4000
#define PWM_BITS 10
#define PWM_MAX  ((1 << PWM_BITS) - 1)

#if ESP_ARDUINO_VERSION_MAJOR >= 3
  #define PWM_ATTACH(pin, ch) ledcAttach((pin), PWM_FREQ, PWM_BITS)
  #define PWM_WRITE(pin, ch, d) ledcWrite((pin), (d))
#else
  #define PWM_ATTACH(pin, ch) do { ledcSetup((ch), PWM_FREQ, PWM_BITS); ledcAttachPin((pin), (ch)); } while (0)
  #define PWM_WRITE(pin, ch, d) ledcWrite((ch), (d))
#endif

// ---------------- สถานะ ----------------
// ล้อ logical: 0=หน้าซ้าย(FL) 1=หน้าขวา(FR) 2=หลังซ้าย(BL) 3=หลังขวา(BR)
struct Cfg {
  bool    inv[4]   = {false, false, false, false};  // กลับทิศล้อ
  uint8_t map[4]   = {1, 2, 0, 3};                  // ล้อ logical -> ช่อง
  int     minPwm   = 22;                            // % แรงเริ่มหมุนขั้นต่ำ
  int     rampMs   = 120;                           // เวลา 0->100% (ms)
  int     trim     = 0;                             // -30..30
  bool    brake    = true;                          // เบรกค้างเมื่อหยุด
} cfg;

int   powerLimit = 85;       // 10..100
bool  turbo      = false;
float target[4]  = {0, 0, 0, 0};   // -100..100
float cur[4]     = {0, 0, 0, 0};
uint32_t lastCmdMs = 0;

int      testWheel = -1;
int      testPct   = 0;
uint32_t testUntil = 0;

const uint32_t FAILSAFE_MS = 400;

WebServer        server(80);
WebSocketsServer ws(81);

#if ENABLE_BLE
BLECharacteristic* bleTx = nullptr;
bool bleConnected = false;
String bleBuf;
#endif

static const char INDEX_HTML[] PROGMEM = R"THEPHTML(
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="theme-color" content="#05070d">
<title>THEP 4WD Controller</title>
<style>
:root{
  --a:#00e5ff; --a-rgb:0,229,255; --glow:1;
  --bg:#05070d; --card:rgba(255,255,255,.045); --line:rgba(255,255,255,.09);
  --txt:#e9f1ff; --dim:#7f8aa3; --rev:#ff3b6b; --ok:#38ff9a; --warn:#ffb020;
  --sat:env(safe-area-inset-top,0px); --sab:env(safe-area-inset-bottom,0px);
  --sal:env(safe-area-inset-left,0px); --sar:env(safe-area-inset-right,0px);
}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;user-select:none;-webkit-user-select:none}
html,body{margin:0;height:100%;overflow:hidden;background:var(--bg);color:var(--txt);
  font-family:"Segoe UI",Roboto,"Noto Sans Thai","Sarabun",system-ui,sans-serif;touch-action:none;overscroll-behavior:none}
body::before{content:"";position:fixed;inset:0;z-index:0;pointer-events:none;
  background:
   radial-gradient(900px 500px at 15% -10%,rgba(var(--a-rgb),.16),transparent 60%),
   radial-gradient(800px 500px at 100% 110%,rgba(var(--a-rgb),.12),transparent 60%),
   linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px) 0 0/34px 34px,
   linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px) 0 0/34px 34px;}
button,select,input{font:inherit;color:inherit}
.hide{display:none!important}

/* ===== Cards (boxes) ===== */
.card{position:relative;background:var(--card);border:1px solid var(--line);border-radius:20px;
  backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);
  box-shadow:0 10px 30px rgba(0,0,0,.45),inset 0 1px 0 rgba(255,255,255,.06)}
.card::after{content:"";position:absolute;inset:-1px;border-radius:21px;padding:1px;pointer-events:none;
  background:linear-gradient(135deg,rgba(var(--a-rgb),calc(.55*var(--glow))),transparent 35%,transparent 65%,rgba(var(--a-rgb),calc(.35*var(--glow))));
  -webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask-composite:exclude}
.cap{font-size:10px;letter-spacing:.22em;text-transform:uppercase;color:var(--dim);font-weight:700}
.btn{border:1px solid var(--line);background:rgba(255,255,255,.06);border-radius:14px;padding:11px 16px;font-weight:700;
  letter-spacing:.06em;cursor:pointer;transition:.15s;display:inline-flex;align-items:center;justify-content:center;gap:8px}
.btn:active{transform:scale(.96)}
.btn.pri{background:linear-gradient(135deg,rgba(var(--a-rgb),.95),rgba(var(--a-rgb),.55));color:#031016;border-color:transparent;
  box-shadow:0 0 calc(24px*var(--glow)) rgba(var(--a-rgb),.55)}
.btn.on{background:rgba(var(--a-rgb),.2);border-color:var(--a);color:var(--a);box-shadow:0 0 calc(18px*var(--glow)) rgba(var(--a-rgb),.4)}
.btn:disabled{opacity:.35;pointer-events:none}

/* ===== Connect screen ===== */
#connect{position:fixed;inset:0;z-index:5;display:flex;align-items:center;justify-content:center;
  padding:calc(var(--sat) + 14px) calc(var(--sar) + 14px) calc(var(--sab) + 14px) calc(var(--sal) + 14px)}
.cwrap{width:min(980px,100%);height:min(560px,100%);display:grid;grid-template-columns:1.1fr 1fr;gap:16px}
.hero{display:flex;align-items:center;justify-content:center;overflow:hidden;position:relative}
.radar{position:absolute;width:min(78%,420px);aspect-ratio:1;border-radius:50%;
  border:1px solid rgba(var(--a-rgb),.35);
  background:conic-gradient(from 0deg,rgba(var(--a-rgb),.0) 0 70%,rgba(var(--a-rgb),.38) 100%);
  -webkit-mask:radial-gradient(circle,transparent 0 22%,#000 23%);mask:radial-gradient(circle,transparent 0 22%,#000 23%);
  animation:spin 3.2s linear infinite;opacity:.0;transition:.4s}
body.scanning .radar{opacity:1}
.ring{position:absolute;width:min(60%,320px);aspect-ratio:1;border-radius:50%;border:1px dashed rgba(var(--a-rgb),.35);animation:spin 22s linear infinite reverse}
@keyframes spin{to{transform:rotate(360deg)}}
.hero svg{width:min(46%,230px);height:auto;position:relative;z-index:2;filter:drop-shadow(0 0 calc(22px*var(--glow)) rgba(var(--a-rgb),.65));animation:float 4s ease-in-out infinite}
@keyframes float{50%{transform:translateY(-8px)}}
.cpanel{padding:20px 22px 16px;display:flex;flex-direction:column;gap:10px;overflow:auto;min-height:0}
.brand{font-size:30px;font-weight:900;letter-spacing:.14em;line-height:1}
.brand b{color:var(--a);text-shadow:0 0 calc(18px*var(--glow)) rgba(var(--a-rgb),.9)}
.sub{color:var(--dim);font-size:12px;letter-spacing:.12em}
.cstat{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:12px;background:rgba(0,0,0,.28);border:1px solid var(--line);font-size:13px;min-height:42px}
.dot{width:9px;height:9px;border-radius:50%;background:var(--dim);flex:none}
.dot.ok{background:var(--ok);box-shadow:0 0 10px var(--ok)} .dot.busy{background:var(--warn);animation:blink .8s infinite} .dot.err{background:var(--rev)}
@keyframes blink{50%{opacity:.2}}
.cbtns{display:grid;gap:10px}
.iprow{display:flex;gap:8px;align-items:center}
.iprow input{flex:1;min-width:0;background:rgba(0,0,0,.3);border:1px solid var(--line);border-radius:12px;padding:10px 12px;outline:none;user-select:text;-webkit-user-select:text}
.iprow input:focus{border-color:var(--a)}
.tiny{font-size:11px;color:var(--dim);line-height:1.5}

/* ===== Control screen ===== */
#ctrl{position:fixed;inset:0;z-index:2;display:grid;gap:10px;
  padding:calc(var(--sat) + 8px) calc(var(--sar) + 10px) calc(var(--sab) + 8px) calc(var(--sal) + 10px);
  grid-template-rows:auto 1fr;grid-template-columns:1fr minmax(0,1.15fr) 1fr;
  grid-template-areas:"top top top" "left mid right"}
#top{grid-area:top;display:flex;align-items:center;gap:8px;padding:7px 10px 7px 14px}
#top .tt{white-space:nowrap;font-weight:900;letter-spacing:.14em;font-size:15px}
#top .tt b{color:var(--a);text-shadow:0 0 calc(12px*var(--glow)) rgba(var(--a-rgb),.9)}
.chip{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:700;letter-spacing:.08em;padding:5px 10px;border-radius:999px;background:rgba(0,0,0,.3);border:1px solid var(--line);white-space:nowrap}
.sp{flex:1}
.ibtn{width:38px;height:38px;border-radius:12px;border:1px solid var(--line);background:rgba(255,255,255,.06);display:grid;place-items:center;cursor:pointer}
.ibtn svg{width:19px;height:19px;stroke:var(--txt);fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.ibtn:active{transform:scale(.92)}
#cl{grid-area:left}#cr{grid-area:right}#cm{grid-area:mid}
.padcard{display:flex;flex-direction:column;padding:12px;min-height:0}
.padcard .cap{display:flex;justify-content:space-between}
.padcard .val{color:var(--a);font-variant-numeric:tabular-nums}
.padwrap{flex:1;min-height:0;display:flex;align-items:center;justify-content:center;padding:6px}
.pad{position:relative;touch-action:none;border-radius:999px;
  background:radial-gradient(circle at 50% 50%,rgba(var(--a-rgb),.10),rgba(0,0,0,.35) 70%);
  border:1px solid rgba(var(--a-rgb),.35);box-shadow:inset 0 0 40px rgba(0,0,0,.6),0 0 calc(22px*var(--glow)) rgba(var(--a-rgb),.18)}
.pad.xy{height:100%;aspect-ratio:1;max-width:100%}
.pad.y{height:100%;width:34%;max-width:130px;min-width:84px;border-radius:70px}
.pad.x{width:100%;height:34%;max-height:130px;min-height:84px;border-radius:70px}
.pad::before{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;
  background:
   linear-gradient(rgba(var(--a-rgb),.25),rgba(var(--a-rgb),.25)) center/1px 76% no-repeat,
   linear-gradient(rgba(var(--a-rgb),.25),rgba(var(--a-rgb),.25)) center/76% 1px no-repeat}
.pad.y::before{background:repeating-linear-gradient(180deg,rgba(var(--a-rgb),.35) 0 2px,transparent 2px 12.5%) center/46% 100% no-repeat}
.pad.x::before{background:repeating-linear-gradient(90deg,rgba(var(--a-rgb),.35) 0 2px,transparent 2px 12.5%) center/100% 46% no-repeat}
.knob{position:absolute;left:50%;top:50%;width:64px;height:64px;margin:-32px 0 0 -32px;border-radius:50%;pointer-events:none;
  background:radial-gradient(circle at 35% 30%,#fff,rgba(var(--a-rgb),1) 35%,rgba(var(--a-rgb),.55) 100%);
  box-shadow:0 0 calc(26px*var(--glow)) rgba(var(--a-rgb),.9),0 6px 14px rgba(0,0,0,.6),inset 0 -4px 10px rgba(0,0,0,.35);
  transition:transform .14s cubic-bezier(.2,1.4,.4,1)}
.pad.drag .knob{transition:none}
.pad .lbl{white-space:nowrap;position:absolute;font-size:10px;font-weight:800;letter-spacing:.18em;color:var(--dim);pointer-events:none}
.pad.y .lbl.t{top:8px;left:50%;transform:translateX(-50%)}.pad.y .lbl.b{bottom:8px;left:50%;transform:translateX(-50%)}
.pad.x .lbl.l{left:12px;top:50%;transform:translateY(-50%)}.pad.x .lbl.r{right:12px;top:50%;transform:translateY(-50%)}
.pad.xy .lbl.t{top:8px;left:50%;transform:translateX(-50%)}.pad.xy .lbl.b{bottom:8px;left:50%;transform:translateX(-50%)}
.pad.xy .lbl.l{left:10px;top:50%;transform:translateY(-50%)}.pad.xy .lbl.r{right:10px;top:50%;transform:translateY(-50%)}

#cm{display:flex;flex-direction:column;gap:10px;min-height:0}
.carbox{flex:1;min-height:0;display:flex;align-items:center;justify-content:center;padding:8px;position:relative;overflow:hidden}
.carbox svg{height:100%;max-width:100%;filter:drop-shadow(0 0 calc(14px*var(--glow)) rgba(var(--a-rgb),.5))}
.carbox .tag{position:absolute;left:12px;top:10px}
.carbox .spd{position:absolute;right:12px;top:8px;text-align:right}
.spd b{display:block;font-size:30px;line-height:1;font-weight:900;color:var(--a);text-shadow:0 0 calc(14px*var(--glow)) rgba(var(--a-rgb),.8);font-variant-numeric:tabular-nums}
.ctl{padding:10px 12px;display:grid;gap:9px}
.row{display:flex;align-items:center;gap:10px}
input[type=range]{-webkit-appearance:none;appearance:none;width:100%;height:30px;background:transparent;margin:0;touch-action:pan-y}
input[type=range]::-webkit-slider-runnable-track{height:8px;border-radius:8px;background:linear-gradient(90deg,var(--a) var(--p,50%),rgba(255,255,255,.12) var(--p,50%))}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:26px;height:26px;border-radius:50%;margin-top:-9px;background:#fff;border:3px solid var(--a);box-shadow:0 0 calc(14px*var(--glow)) rgba(var(--a-rgb),.9)}
input[type=range]::-moz-range-track{height:8px;border-radius:8px;background:rgba(255,255,255,.12)}
input[type=range]::-moz-range-progress{height:8px;border-radius:8px;background:var(--a)}
input[type=range]::-moz-range-thumb{width:20px;height:20px;border-radius:50%;background:#fff;border:3px solid var(--a)}
.pw{min-width:48px;text-align:right;font-weight:900;color:var(--a);font-variant-numeric:tabular-nums}
.act{display:grid;grid-template-columns:1fr 1fr 1.2fr;gap:8px}
.act .btn{padding:10px 6px;font-size:12px}
.btn.stop{background:linear-gradient(135deg,#ff3b6b,#b3123a);border-color:transparent;color:#fff;box-shadow:0 0 calc(18px*var(--glow)) rgba(255,59,107,.5)}
.btn.turbo.on{background:linear-gradient(135deg,#ffb020,#ff5a1f);color:#1a0b00;border-color:transparent;box-shadow:0 0 22px rgba(255,140,30,.7)}

/* ===== Settings drawer ===== */
#scrim{position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:20;opacity:0;pointer-events:none;transition:.25s}
#scrim.show{opacity:1;pointer-events:auto}
#drawer{position:fixed;top:0;right:0;bottom:0;width:min(430px,94vw);z-index:21;transform:translateX(105%);transition:transform .3s cubic-bezier(.2,.9,.3,1);
  background:rgba(8,11,20,.94);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border-left:1px solid var(--line);
  display:flex;flex-direction:column;padding-top:var(--sat);padding-bottom:var(--sab)}
#drawer.show{transform:none}
.dh{display:flex;align-items:center;justify-content:space-between;padding:14px 16px;border-bottom:1px solid var(--line);font-weight:900;letter-spacing:.14em}
.db{flex:1;overflow-y:auto;overflow-x:hidden;padding:12px 14px 24px;display:grid;gap:12px;align-content:start;touch-action:pan-y;-webkit-overflow-scrolling:touch}
.box{padding:14px;display:grid;gap:11px}
.box h3{margin:0;font-size:12px;letter-spacing:.2em;color:var(--a);text-transform:uppercase}
.fld{display:grid;gap:4px}
.fld .top{display:flex;justify-content:space-between;font-size:12px}
.fld .top span:last-child{color:var(--a);font-weight:800;font-variant-numeric:tabular-nums}
.fld small{color:var(--dim);font-size:11px;line-height:1.4}
.sw{display:flex;gap:9px;flex-wrap:wrap}
.sw i{width:34px;height:34px;border-radius:50%;border:2px solid rgba(255,255,255,.25);cursor:pointer;box-shadow:0 0 12px var(--c)}
.sw i.sel{border-color:#fff;transform:scale(1.12)}
input[type=color]{width:48px;height:34px;border:none;background:none;padding:0;border-radius:10px}
.seg{display:grid;grid-auto-flow:column;gap:6px}
.seg .btn{padding:9px 6px;font-size:12px}
.toggle{display:flex;justify-content:space-between;align-items:center;font-size:13px}
.tg{width:48px;height:28px;border-radius:20px;background:rgba(255,255,255,.14);position:relative;cursor:pointer;transition:.2s;flex:none}
.tg::after{content:"";position:absolute;top:3px;left:3px;width:22px;height:22px;border-radius:50%;background:#fff;transition:.2s}
.tg.on{background:var(--a);box-shadow:0 0 calc(12px*var(--glow)) rgba(var(--a-rgb),.7)}.tg.on::after{left:23px}
.mt{display:grid;grid-template-columns:1.1fr 1.6fr auto auto;gap:6px;align-items:center;font-size:12px}
.mt select{background:rgba(0,0,0,.4);border:1px solid var(--line);border-radius:10px;padding:8px 4px;min-width:0;width:100%;font-size:11px}
.mt .btn{padding:8px 10px;font-size:11px}
.warnbox{border-left:3px solid var(--warn);padding:8px 10px;background:rgba(255,176,32,.08);border-radius:8px;font-size:11px;color:#ffd48a;line-height:1.5}

#toast{position:fixed;left:50%;bottom:calc(var(--sab) + 18px);transform:translate(-50%,40px);opacity:0;z-index:50;padding:10px 16px;border-radius:14px;
  background:rgba(10,14,26,.95);border:1px solid var(--a);font-size:13px;transition:.25s;pointer-events:none;max-width:90vw;text-align:center}
#toast.show{transform:translate(-50%,0);opacity:1}

/* ===== Portrait ===== */
@media (orientation:portrait){
  .cwrap{grid-template-columns:1fr;grid-template-rows:minmax(150px,.7fr) auto;height:100%}
  .brand{font-size:24px}
  #ctrl{grid-template-columns:1fr 1fr;grid-template-rows:auto minmax(0,1fr) minmax(0,.95fr);
    grid-template-areas:"top top" "mid mid" "left right"}
  #cm{flex-direction:row;gap:8px}
  #cm .carbox{flex:1}
  #cm .ctl{width:46%;min-width:0;align-content:center}
  #cm .carbox{min-width:0}
  .ctl .row{flex-wrap:wrap;gap:4px 8px}.ctl .row .cap{width:auto!important}
  .ctl input[type=range]{flex:1 1 100%;order:3}
  .act{grid-template-columns:1fr 1fr}.act .stop{grid-column:1/-1}
  #tping{display:none}
  .pad.y{width:46%}
}
@media (max-height:420px) and (orientation:landscape){
  .knob{width:54px;height:54px;margin:-27px 0 0 -27px}
  #top{padding:4px 8px 4px 12px}.ibtn{width:34px;height:34px}
  .spd b{font-size:24px}
  .ctl{padding:8px 10px;gap:6px}
  .brand{font-size:24px}
}
</style>
</head>
<body class="">

<!-- ================= CONNECT ================= -->
<section id="connect">
 <div class="cwrap">
  <div class="card hero">
   <div class="radar"></div><div class="ring"></div>
   <svg class="carsvg" viewBox="0 0 200 320" aria-hidden="true">
     <defs>
       <linearGradient id="bodyg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1b2238"/><stop offset="1" stop-color="#0a0e19"/></linearGradient>
       <linearGradient id="glass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="rgba(var(--a-rgb),.9)"/><stop offset="1" stop-color="rgba(var(--a-rgb),.15)"/></linearGradient>
     </defs>
     <g class="wheels" fill="#06080f" stroke="var(--a)" stroke-width="2.2">
       <rect x="14" y="52" width="30" height="62" rx="9"/><rect x="156" y="52" width="30" height="62" rx="9"/>
       <rect x="14" y="204" width="30" height="62" rx="9"/><rect x="156" y="204" width="30" height="62" rx="9"/>
     </g>
     <g stroke="var(--a)" stroke-width="1.6" opacity=".55">
       <path d="M20 66h18M20 78h18M20 90h18M20 102h18M162 66h18M162 78h18M162 90h18M162 102h18M20 218h18M20 230h18M20 242h18M20 254h18M162 218h18M162 230h18M162 242h18M162 254h18"/>
     </g>
     <path d="M44 84h112M44 236h112" stroke="var(--a)" stroke-width="5" opacity=".6"/>
     <path d="M62 14 Q100 2 138 14 L158 70 Q166 160 158 252 L142 304 Q100 316 58 304 L42 252 Q34 160 42 70 Z" fill="url(#bodyg)" stroke="var(--a)" stroke-width="2.4"/>
     <path d="M70 108 Q100 98 130 108 L138 168 Q100 176 62 168 Z" fill="url(#glass)" stroke="var(--a)" stroke-width="1.4"/>
     <path d="M66 190 Q100 182 134 190 L130 232 Q100 238 70 232 Z" fill="rgba(var(--a-rgb),.2)" stroke="var(--a)" stroke-width="1.2"/>
     <path d="M100 28v70" stroke="var(--a)" stroke-width="2" opacity=".7"/>
     <path d="M70 38 L86 62 M130 38 L114 62" stroke="var(--a)" stroke-width="2" opacity=".7"/>
     <g class="lights"><path d="M58 22 L82 20 L78 32 L56 34 Z" fill="#fff"/><path d="M142 22 L118 20 L122 32 L144 34 Z" fill="#fff"/></g>
     <path d="M62 300 L84 304 M138 300 L116 304" stroke="var(--rev)" stroke-width="5" stroke-linecap="round"/>
   </svg>
  </div>
  <div class="card cpanel">
   <div><div class="brand">THEP <b>4WD</b></div><div class="sub">PRECISION RC CONTROLLER</div></div>
   <div class="cstat"><span class="dot" id="cdot"></span><span id="cmsg">พร้อมเชื่อมต่อ — เปิดรถ ESP32 แล้วเลือกวิธีด้านล่าง</span></div>
   <div class="cbtns">
     <button class="btn pri" id="btnBle">
       <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6.5 7.5l11 9-5.5 4.5v-17l5.5 4.5-11 9"/></svg>
       เชื่อมต่อ BLUETOOTH</button>
     <button class="btn" id="btnWifi">
       <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M2 9a15 15 0 0 1 20 0M5.5 12.5a10 10 0 0 1 13 0M9 16a5 5 0 0 1 6 0"/><circle cx="12" cy="19.5" r="1" fill="currentColor"/></svg>
       เชื่อมต่อ WIFI (THEP-4WD)</button>
     <div class="iprow"><span class="tiny">IP รถ</span><input id="ip" inputmode="decimal" value="192.168.4.1"></div>
     <button class="btn" id="btnDemo">ทดลองใช้งาน (ไม่ต่อรถ)</button>
   </div>
   <div class="tiny" id="chint"></div>
  </div>
 </div>
</section>

<!-- ================= CONTROL ================= -->
<section id="ctrl" class="hide">
  <header id="top" class="card">
    <div class="tt">THEP <b>4WD</b></div>
    <span class="chip"><span class="dot" id="tdot"></span><span id="tlink">—</span></span>
    <span class="chip" id="tping">— ms</span>
    <span class="sp"></span>
    <span class="chip" id="tmode">DUAL</span>
    <button class="ibtn" id="bFull" title="เต็มจอ"><svg viewBox="0 0 24 24"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg></button>
    <button class="ibtn" id="bSet" title="ตั้งค่า"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg></button>
  </header>

  <div id="cl" class="card padcard"></div>

  <div id="cm">
    <div class="card carbox">
      <span class="cap tag" id="ctag">LIVE</span>
      <div class="spd"><span class="cap">SPEED</span><b id="spd">0</b></div>
      <svg id="car" viewBox="0 0 200 320">
        <defs>
          <linearGradient id="bodyg2" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1b2238"/><stop offset="1" stop-color="#0a0e19"/></linearGradient>
          <linearGradient id="glass2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="rgba(var(--a-rgb),.9)"/><stop offset="1" stop-color="rgba(var(--a-rgb),.15)"/></linearGradient>
        </defs>
        <g id="wFL"><rect class="wb" x="12" y="50" width="34" height="66" rx="10" fill="#06080f" stroke="var(--a)" stroke-width="2.4"/><rect class="bar" x="20" y="83" width="18" height="0" rx="4"/></g>
        <g id="wFR"><rect class="wb" x="154" y="50" width="34" height="66" rx="10" fill="#06080f" stroke="var(--a)" stroke-width="2.4"/><rect class="bar" x="162" y="83" width="18" height="0" rx="4"/></g>
        <g id="wBL"><rect class="wb" x="12" y="204" width="34" height="66" rx="10" fill="#06080f" stroke="var(--a)" stroke-width="2.4"/><rect class="bar" x="20" y="237" width="18" height="0" rx="4"/></g>
        <g id="wBR"><rect class="wb" x="154" y="204" width="34" height="66" rx="10" fill="#06080f" stroke="var(--a)" stroke-width="2.4"/><rect class="bar" x="162" y="237" width="18" height="0" rx="4"/></g>
        <path d="M46 84h108M46 237h108" stroke="var(--a)" stroke-width="5" opacity=".6"/>
        <path d="M62 14 Q100 2 138 14 L158 70 Q166 160 158 252 L142 304 Q100 316 58 304 L42 252 Q34 160 42 70 Z" fill="url(#bodyg2)" stroke="var(--a)" stroke-width="2.4"/>
        <path d="M70 108 Q100 98 130 108 L138 168 Q100 176 62 168 Z" fill="url(#glass2)" stroke="var(--a)" stroke-width="1.4"/>
        <path d="M66 190 Q100 182 134 190 L130 232 Q100 238 70 232 Z" fill="rgba(var(--a-rgb),.2)" stroke="var(--a)" stroke-width="1.2"/>
        <path d="M100 28v70M70 38L86 62M130 38L114 62" stroke="var(--a)" stroke-width="2" opacity=".7"/>
        <path d="M58 22L82 20L78 32L56 34Z M142 22L118 20L122 32L144 34Z" fill="#fff"/>
        <path d="M62 300L84 304M138 300L116 304" stroke="var(--rev)" stroke-width="5" stroke-linecap="round" id="tail"/>
        <g id="arrow" opacity="0"><path d="M100 120l-14 22h28z" fill="#fff"/></g>
      </svg>
    </div>
    <div class="card ctl">
      <div class="row"><span class="cap" style="width:54px">POWER</span><input type="range" id="pw" min="10" max="100" value="85"><span class="pw" id="pwv">85%</span></div>
      <div class="act">
        <button class="btn turbo" id="bTurbo">⚡ TURBO</button>
        <button class="btn" id="bFine">FINE</button>
        <button class="btn stop" id="bStop">■ STOP</button>
      </div>
    </div>
  </div>

  <div id="cr" class="card padcard"></div>
</section>

<!-- ================= SETTINGS ================= -->
<div id="scrim"></div>
<aside id="drawer">
  <div class="dh"><span>ตั้งค่า / SETTINGS</span><button class="ibtn" id="bClose"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>
  <div class="db">

   <div class="card box">
     <h3>ธีมสี / RGB</h3>
     <div class="sw" id="sw"></div>
     <div class="row"><span class="tiny" style="width:80px">เลือกสีเอง</span><input type="color" id="colr" value="#00e5ff"></div>
     <div class="toggle"><span>โหมด RGB สายรุ้ง</span><div class="tg" id="tgRgb"></div></div>
     <div class="fld"><div class="top"><span>ความเร็วสีรุ้ง</span><span id="v_rgbSpd"></span></div><input type="range" id="rgbSpd" min="1" max="30" value="8"></div>
     <div class="fld"><div class="top"><span>ความเรืองแสง (Glow)</span><span id="v_glow"></span></div><input type="range" id="glow" min="0" max="150" value="100"></div>
   </div>

   <div class="card box">
     <h3>รูปแบบการบังคับ</h3>
     <div class="seg" id="modeSeg">
       <button class="btn" data-m="dual">แยกคันเร่ง/เลี้ยว</button>
       <button class="btn" data-m="single">จอยเดียว</button>
       <button class="btn" data-m="tank">แท็งก์ซ้าย/ขวา</button>
     </div>
     <div class="tiny" id="modeDesc"></div>
     <div class="fld"><div class="top"><span>ความนุ่มช่วงต้น (Expo)</span><span id="v_expo"></span></div><input type="range" id="expo" min="0" max="90" value="35"><small>มากขึ้น = ขยับเล็กน้อยแล้วคุมละเอียดขึ้น เต็มสุดยังแรงเท่าเดิม</small></div>
     <div class="fld"><div class="top"><span>Deadzone</span><span id="v_dz"></span></div><input type="range" id="dz" min="0" max="30" value="6"></div>
     <div class="fld"><div class="top"><span>ความไวการเลี้ยว</span><span id="v_steer"></span></div><input type="range" id="steer" min="30" max="130" value="100"></div>
     <div class="fld"><div class="top"><span>โหมด FINE (ละเอียด) = กำลัง</span><span id="v_fine"></span></div><input type="range" id="fine" min="15" max="70" value="40"></div>
     <div class="toggle"><span>สั่นเมื่อกดปุ่ม</span><div class="tg" id="tgHap"></div></div>
   </div>

   <div class="card box">
     <h3>จูนรถ (ส่งเข้า ESP32)</h3>
     <div class="fld"><div class="top"><span>กำลังเริ่มหมุน (ขั้นต่ำ)</span><span id="v_minp"></span></div><input type="range" id="minp" min="0" max="60" value="22"><small>มอเตอร์ L298N ต้องมีแรงเริ่มต้น ถ้าขยับจอยนิดเดียวแล้วรถครางไม่ขยับให้เพิ่มค่านี้</small></div>
     <div class="fld"><div class="top"><span>ความนุ่มเร่ง/เบรก (Ramp)</span><span id="v_ramp"></span></div><input type="range" id="ramp" min="0" max="800" step="10" value="120"><small>0 = ตอบสนองทันที, มากขึ้น = ออกตัวนุ่ม ล้อไม่ฟรี</small></div>
     <div class="fld"><div class="top"><span>ชดเชยขับตรง (Trim)</span><span id="v_trim"></span></div><input type="range" id="trim" min="-30" max="30" value="0"><small>ถ้ารถเฉไปทางซ้ายตอนวิ่งตรง ให้เลื่อนไปทางขวา (+) และกลับกัน</small></div>
     <div class="toggle"><span>เบรกค้างเมื่อปล่อยจอย</span><div class="tg" id="tgBrake"></div></div>
   </div>

   <div class="card box">
     <h3>ตรวจ/ตั้งค่ามอเตอร์ 4 ล้อ</h3>
     <div class="warnbox">ยกรถให้ล้อลอยก่อนทดสอบ กด “ทดสอบ” ล้อต้องหมุนเดินหน้า (หน้ารถ) ถ้าหมุนผิดทิศให้ติ๊ก “กลับ” ถ้าหมุนผิดล้อให้เปลี่ยนช่อง</div>
     <div id="mtab" class="grid" style="display:grid;gap:8px"></div>
     <div class="row" style="gap:8px">
       <button class="btn" id="tFwd" style="flex:1;font-size:12px">ทดสอบเดินหน้า</button>
       <button class="btn" id="tSpin" style="flex:1;font-size:12px">ทดสอบหมุนขวาอยู่กับที่</button>
     </div>
     <button class="btn" id="bPush" style="font-size:12px">ส่งค่าเข้ารถอีกครั้ง</button>
   </div>

   <div class="card box">
     <h3>การเชื่อมต่อ</h3>
     <div class="tiny" id="linfo">—</div>
     <button class="btn stop" id="bDisc">ตัดการเชื่อมต่อ</button>
     <button class="btn" id="bReset" style="font-size:12px">รีเซ็ตการตั้งค่าทั้งหมด</button>
   </div>
  </div>
</aside>
<div id="toast"></div>

<script>
"use strict";
/* ============================================================
   THEP 4WD Controller  —  UI + link layer
   Protocol (text lines, '\n' terminated):
     J,x,y          joystick  (-100..100)  x=right+  y=forward+
     T,l,r          tank      (-100..100)
     P,n            power limit 10..100
     B,0|1          turbo
     X              stop
     M,i,dir,pct    test wheel i (0 FL,1 FR,2 BL,3 BR)
     CFG,...        tuning / calibration
     PING,t         -> PONG,t
   Car -> phone:  O,fl,fr,bl,br,power,turbo     PONG,t
   ============================================================ */
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const DEFAULTS={color:"#00e5ff",rgb:false,rgbSpd:8,glow:100,mode:"dual",expo:35,dz:6,steer:100,fine:40,hap:true,
  minp:22,ramp:120,trim:0,brake:true,power:85,inv:[0,0,0,0],map:[1,2,0,3],ip:"192.168.4.1"};
let S;
try{S=Object.assign({},DEFAULTS,JSON.parse(localStorage.getItem("thep4wd")||"{}"))}catch(e){S=Object.assign({},DEFAULTS)}
S.inv=(S.inv&&S.inv.length===4)?S.inv:DEFAULTS.inv.slice(); S.map=(S.map&&S.map.length===4)?S.map:DEFAULTS.map.slice();
function save(){try{localStorage.setItem("thep4wd",JSON.stringify(S))}catch(e){}}

/* ---------- toast / haptics ---------- */
let tT; function toast(m){const t=$("#toast");t.textContent=m;t.classList.add("show");clearTimeout(tT);tT=setTimeout(()=>t.classList.remove("show"),2200)}
function hap(ms){if(S.hap&&navigator.vibrate)try{navigator.vibrate(ms||12)}catch(e){}}

/* ---------- theme ---------- */
const PRESETS=["#00e5ff","#39ff88","#b6ff00","#ffb020","#ff5a1f","#ff2d6f","#c04dff","#4d7cff","#ffffff"];
function hexToRgb(h){const n=parseInt(h.slice(1),16);return [(n>>16)&255,(n>>8)&255,n&255]}
function hslToRgb(h,s,l){h/=360;const f=(n)=>{const k=(n+h*12)%12,a=s*Math.min(l,1-l);return l-a*Math.max(-1,Math.min(k-3,9-k,1))};return[Math.round(f(0)*255),Math.round(f(8)*255),Math.round(f(4)*255)]}
function applyColor(rgb){const r=document.documentElement.style;r.setProperty("--a",`rgb(${rgb})`);r.setProperty("--a-rgb",rgb.join(","));
  const m=document.querySelector('meta[name=theme-color]');}
let hue=190;
function themeTick(){ if(S.rgb){hue=(hue+S.rgbSpd*0.06)%360;applyColor(hslToRgb(hue,1,.55))} }
setInterval(themeTick,40);
function applyTheme(){
  document.documentElement.style.setProperty("--glow",S.glow/100);
  if(!S.rgb)applyColor(hexToRgb(S.color));
  $("#colr").value=S.color;
  $$("#sw i").forEach(i=>i.classList.toggle("sel",!S.rgb&&i.dataset.c.toLowerCase()===S.color.toLowerCase()));
  $("#tgRgb").classList.toggle("on",S.rgb);
}
$("#sw").innerHTML=PRESETS.map(c=>`<i data-c="${c}" style="background:${c};--c:${c}"></i>`).join("");
$("#sw").addEventListener("click",e=>{const c=e.target.dataset&&e.target.dataset.c;if(!c)return;S.color=c;S.rgb=false;save();applyTheme();hap()});
$("#colr").addEventListener("input",e=>{S.color=e.target.value;S.rgb=false;save();applyTheme()});
$("#tgRgb").onclick=()=>{S.rgb=!S.rgb;if(!S.rgb)applyTheme();save();applyTheme();hap()};

/* ---------- sliders binding ---------- */
function bindRange(id,key,fmt,after){
  const el=$("#"+id), lab=$("#v_"+id);
  const upd=()=>{const p=(el.value-el.min)/(el.max-el.min)*100;el.style.setProperty("--p",p+"%");if(lab)lab.textContent=fmt?fmt(+el.value):el.value};
  el.value=S[key];upd();
  el.addEventListener("input",()=>{S[key]=+el.value;upd();save();after&&after()});
  el._upd=upd;
}
bindRange("rgbSpd","rgbSpd");
bindRange("glow","glow",v=>v+"%",applyTheme);
bindRange("expo","expo",v=>v+"%");
bindRange("dz","dz",v=>v+"%");
bindRange("steer","steer",v=>v+"%");
bindRange("fine","fine",v=>v+"%");
bindRange("minp","minp",v=>v+"%",pushCfgSoon);
bindRange("ramp","ramp",v=>v+" ms",pushCfgSoon);
bindRange("trim","trim",v=>(v>0?"+":"")+v+(v>0?" →":v<0?" ←":""),pushCfgSoon);
/* main power slider */
{const el=$("#pw");const upd=()=>{el.style.setProperty("--p",((el.value-10)/90*100)+"%");$("#pwv").textContent=el.value+"%"};
 el.value=S.power;upd();
 el.addEventListener("input",()=>{S.power=+el.value;upd();save();send("P,"+S.power)});}
function toggleBind(id,key,after){const t=$(id);t.classList.toggle("on",!!S[key]);t.onclick=()=>{S[key]=!S[key];t.classList.toggle("on",!!S[key]);save();hap();after&&after()}}
toggleBind("#tgHap","hap");toggleBind("#tgBrake","brake",pushCfgSoon);

/* ---------- modes ---------- */
const MODES={dual:{n:"DUAL",d:"ซ้าย = คันเร่ง เดินหน้า/ถอยหลัง · ขวา = เลี้ยว ซ้าย/ขวา (ละเอียดที่สุด หมุนอยู่กับที่ได้โดยดันขวาอย่างเดียว)"},
  single:{n:"SINGLE",d:"จอยโยกเดียวแบบอาร์เคด ใช้ได้ทั้งสองข้าง ขึ้น/ลง = เดินหน้า/ถอย, ซ้าย/ขวา = เลี้ยว"},
  tank:{n:"TANK",d:"คันเร่งแยกล้อซ้าย/ขวา เหมือนรถแท็งก์ ดันคนละทิศ = หมุนอยู่กับที่"}};
$$("#modeSeg .btn").forEach(b=>b.onclick=()=>{S.mode=b.dataset.m;save();buildPads();hap()});

/* ---------- pads ---------- */
const pads=[];  // {el,type,x,y}
function mkPad(host,type,title,labels){
  host.innerHTML=`<div class="cap"><span>${title}</span><span class="val">0</span></div><div class="padwrap"><div class="pad ${type}"><div class="knob"></div></div></div>`;
  const pad=host.querySelector(".pad"),knob=host.querySelector(".knob"),val=host.querySelector(".val");
  (labels||[]).forEach(([c,t])=>{const s=document.createElement("span");s.className="lbl "+c;s.textContent=t;pad.appendChild(s)});
  const P={type,x:0,y:0,id:null,pad};
  function setKnob(){const r=pad.getBoundingClientRect(),kr=knob.offsetWidth/2;
    let tx=0,ty=0;
    if(type==="xy"){const R=Math.min(r.width,r.height)/2-kr;tx=P.x*R;ty=-P.y*R}
    if(type==="y"){ty=-P.y*(r.height/2-kr-4)}
    if(type==="x"){tx=P.x*(r.width/2-kr-4)}
    knob.style.transform=`translate(${tx}px,${ty}px)`;
    val.textContent=type==="x"?Math.round(P.x*100):type==="y"?Math.round(P.y*100):Math.round(Math.hypot(P.x,P.y)*100);
  }
  function move(e){const r=pad.getBoundingClientRect(),kr=knob.offsetWidth/2,cx=r.left+r.width/2,cy=r.top+r.height/2;
    const dx=e.clientX-cx,dy=e.clientY-cy;
    if(type==="xy"){const R=Math.min(r.width,r.height)/2-kr;let vx=dx/R,vy=-dy/R;const m=Math.hypot(vx,vy);if(m>1){vx/=m;vy/=m}P.x=vx;P.y=vy}
    if(type==="y"){P.y=clamp(-dy/(r.height/2-kr-4),-1,1)}
    if(type==="x"){P.x=clamp(dx/(r.width/2-kr-4),-1,1)}
    setKnob();
  }
  pad.addEventListener("pointerdown",e=>{if(P.id!==null)return;P.id=e.pointerId;pad.setPointerCapture(e.pointerId);pad.classList.add("drag");move(e);hap(8);e.preventDefault()});
  pad.addEventListener("pointermove",e=>{if(e.pointerId===P.id)move(e)});
  const up=e=>{if(e.pointerId!==P.id)return;P.id=null;pad.classList.remove("drag");P.x=0;P.y=0;setKnob()};
  pad.addEventListener("pointerup",up);pad.addEventListener("pointercancel",up);pad.addEventListener("lostpointercapture",up);
  P.reset=()=>{P.x=0;P.y=0;P.id=null;pad.classList.remove("drag");setKnob()};
  P.refresh=setKnob;
  pads.push(P);return P;
}
let L=null,R=null;
function buildPads(){
  pads.length=0;
  $$("#modeSeg .btn").forEach(b=>b.classList.toggle("on",b.dataset.m===S.mode));
  $("#modeDesc").textContent=MODES[S.mode].d;$("#tmode").textContent=MODES[S.mode].n;
  if(S.mode==="dual"){L=mkPad($("#cl"),"y","THROTTLE · คันเร่ง",[["t","FWD ▲"],["b","REV ▼"]]);R=mkPad($("#cr"),"x","STEER · เลี้ยว",[["l","◄ L"],["r","R ►"]])}
  else if(S.mode==="single"){L=mkPad($("#cl"),"xy","DRIVE A",[["t","FWD"],["b","REV"],["l","L"],["r","R"]]);R=mkPad($("#cr"),"xy","DRIVE B",[["t","FWD"],["b","REV"],["l","L"],["r","R"]])}
  else{L=mkPad($("#cl"),"y","LEFT SIDE · ซ้าย",[["t","▲"],["b","▼"]]);R=mkPad($("#cr"),"y","RIGHT SIDE · ขวา",[["t","▲"],["b","▼"]])}
  requestAnimationFrame(()=>pads.forEach(p=>p.refresh()));
}
addEventListener("resize",()=>pads.forEach(p=>p.refresh()));

/* ---------- input shaping ---------- */
function shape(v,dz,expo){ // v -1..1
  const s=Math.sign(v);let a=Math.abs(v);
  dz=dz/100;if(a<dz)return 0;a=(a-dz)/(1-dz);
  const e=expo/100;a=(1-e)*a+e*a*a*a;return s*a;
}
/* ---------- keyboard (desktop test) ---------- */
const keys={};
addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=1;if(e.key===" ")stopAll()});
addEventListener("keyup",e=>{delete keys[e.key.toLowerCase()]});
function kbd(){let y=0,x=0;if(keys.w||keys.arrowup)y+=1;if(keys.s||keys.arrowdown)y-=1;if(keys.d||keys.arrowright)x+=1;if(keys.a||keys.arrowleft)x-=1;return[x,y]}

/* ---------- link layer ---------- */
const NUS="6e400001-b5a3-f393-e0a9-e50e24dcca9e",NUS_RX="6e400002-b5a3-f393-e0a9-e50e24dcca9e",NUS_TX="6e400003-b5a3-f393-e0a9-e50e24dcca9e";
const Link={type:null,ok:false,demo:false,ws:null,dev:null,rx:null,busy:false,q:[],ping:0,lastRx:0};
function setConnMsg(t,k){$("#cmsg").textContent=t;$("#cdot").className="dot "+(k||"")}
function send(line){
  if(Link.demo){demoRx(line);return}
  if(!Link.ok)return;
  if(Link.type==="ws"){if(Link.ws.readyState===1)Link.ws.send(line+"\n")}
  else if(Link.type==="ble"){
    // drop stale motion commands when queue is long (keep newest)
    if(/^[JT],/.test(line)){Link.q=Link.q.filter(l=>!/^[JT],/.test(l))}
    Link.q.push(line);bleFlush();
  }
}
async function bleFlush(){
  if(Link.busy||!Link.rx)return;Link.busy=true;
  try{
    while(Link.q.length){
      const bytes=new TextEncoder().encode(Link.q.shift()+"\n");
      for(let i=0;i<bytes.length;i+=20){
        const ch=bytes.slice(i,i+20);
        if(Link.rx.writeValueWithoutResponse)await Link.rx.writeValueWithoutResponse(ch);else await Link.rx.writeValue(ch);
      }
    }
  }catch(e){}
  Link.busy=false;
}
let rxBuf="";
function onData(txt){rxBuf+=txt;let i;while((i=rxBuf.indexOf("\n"))>=0){const l=rxBuf.slice(0,i).trim();rxBuf=rxBuf.slice(i+1);if(l)onLine(l)}}
function onLine(l){
  Link.lastRx=performance.now();
  const p=l.split(",");
  if(p[0]==="O"){out=[+p[1],+p[2],+p[3],+p[4]];if(p[5])carPower=+p[5]}
  else if(p[0]==="PONG"){Link.ping=Math.round(performance.now()-(+p[1]));$("#tping").textContent=Link.ping+" ms"}
}
function showCtrl(){$("#connect").classList.add("hide");$("#ctrl").classList.remove("hide");document.body.classList.remove("scanning");buildPads();
  const k=Link.demo?"DEMO":Link.type==="ble"?"BLUETOOTH":"WIFI";$("#tlink").textContent=k;$("#tdot").className="dot "+(Link.demo?"busy":"ok");
  $("#linfo").textContent=Link.demo?"โหมดทดลอง — ไม่ได้ต่อกับรถ":Link.type==="ble"?"Bluetooth LE · THEP-4WD":"WiFi WebSocket · ws://"+$("#ip").value+":81";
  pushCfg();send("P,"+S.power);}
function showConnect(msg,k){$("#ctrl").classList.add("hide");$("#connect").classList.remove("hide");document.body.classList.remove("scanning");closeDrawer();
  if(msg)setConnMsg(msg,k||"err");}
function onLost(why){if(!Link.ok&&!Link.demo)return;Link.ok=false;Link.demo=false;try{Link.ws&&Link.ws.close()}catch(e){}Link.q=[];Link.rx=null;showConnect(why||"การเชื่อมต่อหลุด — รถหยุดอัตโนมัติ","err");hap([60,40,60])}

async function connectBle(){
  if(!navigator.bluetooth){setConnMsg("หน้านี้ใช้ Bluetooth ไม่ได้ (ต้องเปิดด้วย Chrome บน Android ผ่าน HTTPS) — ใช้ WiFi แทนได้","err");return}
  try{
    setConnMsg("กำลังค้นหา THEP-4WD …","busy");document.body.classList.add("scanning");
    const dev=await navigator.bluetooth.requestDevice({filters:[{services:[NUS]},{namePrefix:"THEP"}],optionalServices:[NUS]});
    setConnMsg("กำลังเชื่อมต่อ "+(dev.name||"รถ")+" …","busy");
    dev.addEventListener("gattserverdisconnected",()=>{if(Link.type==="ble")onLost("Bluetooth หลุด — รถหยุดอัตโนมัติ")});
    const srv=await dev.gatt.connect();const svc=await srv.getPrimaryService(NUS);
    Link.rx=await svc.getCharacteristic(NUS_RX);const tx=await svc.getCharacteristic(NUS_TX);
    await tx.startNotifications();
    const dec=new TextDecoder();tx.addEventListener("characteristicvaluechanged",e=>onData(dec.decode(e.target.value)));
    Link.dev=dev;Link.type="ble";Link.ok=true;Link.demo=false;setConnMsg("เชื่อมต่อสำเร็จ","ok");setTimeout(showCtrl,350);
  }catch(e){document.body.classList.remove("scanning");setConnMsg(e&&e.name==="NotFoundError"?"ยกเลิกการเลือกอุปกรณ์":"เชื่อมต่อไม่สำเร็จ: "+(e.message||e),"err")}
}
function connectWifi(){
  const ip=$("#ip").value.trim()||"192.168.4.1";S.ip=ip;save();
  setConnMsg("กำลังต่อ ws://"+ip+":81 … (ต้องต่อ WiFi ชื่อ THEP-4WD ก่อน)","busy");document.body.classList.add("scanning");
  let ws;try{ws=new WebSocket("ws://"+ip+":81/")}catch(e){setConnMsg("ที่อยู่ไม่ถูกต้อง","err");return}
  let opened=false;const to=setTimeout(()=>{if(!opened){try{ws.close()}catch(e){};document.body.classList.remove("scanning");setConnMsg("ต่อไม่ติด — เช็กว่ามือถือต่อ WiFi “THEP-4WD” (รหัส 12345678) แล้ว","err")}},5000);
  ws.onopen=()=>{opened=true;clearTimeout(to);Link.ws=ws;Link.type="ws";Link.ok=true;Link.demo=false;setConnMsg("เชื่อมต่อสำเร็จ","ok");setTimeout(showCtrl,300)};
  ws.onmessage=e=>onData(String(e.data).replace(/\n?$/,"\n"));
  ws.onclose=()=>{clearTimeout(to);if(Link.type==="ws"&&Link.ok)onLost("WiFi หลุด — รถหยุดอัตโนมัติ")};
  ws.onerror=()=>{};
}
function startDemo(){Link.demo=true;Link.ok=false;Link.type="demo";showCtrl();toast("โหมดทดลอง: ยังไม่ได้ต่อกับรถจริง")}
function disconnect(){const d=Link.demo;try{send("X")}catch(e){}
  if(Link.type==="ble"&&Link.dev&&Link.dev.gatt.connected){const t=Link.type;Link.type=null;Link.dev.gatt.disconnect();Link.ok=false;showConnect("ตัดการเชื่อมต่อแล้ว","");return}
  if(Link.type==="ws"){const w=Link.ws;Link.type=null;Link.ok=false;try{w.close()}catch(e){}}
  Link.ok=false;Link.demo=false;Link.type=null;showConnect("ตัดการเชื่อมต่อแล้ว","")}
$("#btnBle").onclick=connectBle;$("#btnWifi").onclick=connectWifi;$("#btnDemo").onclick=startDemo;$("#bDisc").onclick=disconnect;
$("#ip").value=S.ip;
if(!navigator.bluetooth){$("#chint").innerHTML="💡 หน้านี้ยังใช้ Bluetooth ไม่ได้ (ต้องเปิดด้วย Chrome/Edge บน Android ผ่าน HTTPS) — ถ้าเปิดจาก <b>http://192.168.4.1</b> ให้ใช้ปุ่ม WiFi ซึ่งใช้ได้ทุกเครื่อง"}
else{$("#chint").innerHTML="💡 Bluetooth ต้องเปิด Location/Bluetooth บนมือถือ · หรือใช้ WiFi เมื่อเปิดจาก http://192.168.4.1"}
if(location.protocol==="http:"&&/^\d+\.\d+\.\d+\.\d+$/.test(location.hostname)){$("#ip").value=location.hostname}

/* ---------- config push ---------- */
let cfgT;function pushCfgSoon(){clearTimeout(cfgT);cfgT=setTimeout(pushCfg,250)}
function pushCfg(){send(["CFG",...S.inv.map(v=>v?1:0),...S.map,S.minp,S.ramp,S.trim,S.brake?1:0].join(","))}
$("#bPush").onclick=()=>{pushCfg();send("P,"+S.power);toast("ส่งค่าเข้ารถแล้ว")};

/* ---------- motor calibration table ---------- */
const WN=["หน้าซ้าย FL","หน้าขวา FR","หลังซ้าย BL","หลังขวา BR"];
const CH=["ช่อง 1 · ซ้าย IN1/2 (18/19)","ช่อง 2 · ซ้าย IN3/4 (21/22)","ช่อง 3 · ขวา IN1/2 (33/32)","ช่อง 4 · ขวา IN3/4 (26/27)"];
function buildMT(){
  $("#mtab").innerHTML=WN.map((n,i)=>`<div class="mt"><b>${n}</b>
   <select data-i="${i}">${CH.map((c,j)=>`<option value="${j}" ${S.map[i]===j?"selected":""}>${c}</option>`).join("")}</select>
   <button class="btn ${S.inv[i]?"on":""}" data-inv="${i}">กลับ</button>
   <button class="btn" data-t="${i}">ทดสอบ</button></div>`).join("")}
buildMT();
$("#mtab").addEventListener("change",e=>{const i=e.target.dataset.i;if(i===undefined)return;S.map[+i]=+e.target.value;save();pushCfg()});
$("#mtab").addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;
  if(b.dataset.inv!==undefined){const i=+b.dataset.inv;S.inv[i]=S.inv[i]?0:1;b.classList.toggle("on",!!S.inv[i]);save();pushCfg()}
  if(b.dataset.t!==undefined){pushCfg();send(`M,${b.dataset.t},1,55`);hap()}});
let override=null;
$("#tFwd").onclick=()=>{override={x:0,y:45,until:performance.now()+1500};pushCfg()};
$("#tSpin").onclick=()=>{override={x:45,y:0,until:performance.now()+1500};pushCfg()};

/* ---------- actions ---------- */
let turbo=false,fine=false;
$("#bTurbo").onclick=()=>{turbo=!turbo;$("#bTurbo").classList.toggle("on",turbo);send("B,"+(turbo?1:0));hap(20)};
$("#bFine").onclick=()=>{fine=!fine;$("#bFine").classList.toggle("on",fine);hap(15)};
function stopAll(){pads.forEach(p=>p.reset&&p.reset());override=null;send("X");hap([30,30,30])}
$("#bStop").onclick=stopAll;
$("#bFull").onclick=async()=>{try{if(!document.fullscreenElement){await document.documentElement.requestFullscreen();try{await screen.orientation.lock("landscape")}catch(e){}}else{await document.exitFullscreen()}}catch(e){toast("เบราว์เซอร์ไม่รองรับเต็มจอ")}};
try{navigator.wakeLock&&document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible"&&!$("#ctrl").classList.contains("hide"))navigator.wakeLock.request("screen").catch(()=>{})})}catch(e){}
/* if page hidden → stop */
document.addEventListener("visibilitychange",()=>{if(document.hidden)stopAll()});

/* ---------- drawer ---------- */
function openDrawer(){$("#drawer").classList.add("show");$("#scrim").classList.add("show");pads.forEach(p=>p.reset())}
function closeDrawer(){$("#drawer").classList.remove("show");$("#scrim").classList.remove("show")}
$("#bSet").onclick=openDrawer;$("#bClose").onclick=closeDrawer;$("#scrim").onclick=closeDrawer;
$("#drawer").addEventListener("pointerdown",e=>e.stopPropagation());
$("#bReset").onclick=()=>{if(confirm("รีเซ็ตการตั้งค่าทั้งหมด?")){try{localStorage.removeItem("thep4wd")}catch(e){}location.reload()}};

/* ---------- main loop ---------- */
let lastCmd="",lastSend=0,out=[0,0,0,0],carPower=85,demoOut=[0,0,0,0],demoT=[0,0,0,0],demoPow=85,demoTurbo=false,demoLimit=85;
function computeCmd(){
  const now=performance.now();
  if(override){if(now>override.until)override=null;else return`J,${override.x},${override.y}`}
  const k=kbd(); const fm=fine?S.fine/100:1;
  if(S.mode==="tank"){
    const l=shape(L.y,S.dz,S.expo)*fm*100,r=shape(R.y,S.dz,S.expo)*fm*100;
    return`T,${Math.round(l)},${Math.round(r)}`;
  }
  let x,y;
  if(S.mode==="dual"){y=L.y;x=R.x}
  else{ // single: sum both sticks
    y=clamp(L.y+R.y,-1,1);x=clamp(L.x+R.x,-1,1)}
  if(k[0]||k[1]){x=k[0];y=k[1]}
  let ys=shape(y,S.dz,S.expo),xs=shape(x,S.dz,S.expo)*(S.steer/100);
  return`J,${Math.round(clamp(xs*fm,-1,1)*100)},${Math.round(clamp(ys*fm,-1,1)*100)}`;
}
function loop(){
  if(!$("#ctrl").classList.contains("hide")&&!document.hidden&&pads.length){
    const c=computeCmd(),now=performance.now();
    if(c!==lastCmd||now-lastSend>110){send(c);lastCmd=c;lastSend=now}
  }
}
setInterval(loop,33);
setInterval(()=>{if(Link.ok&&!Link.demo)send("PING,"+Math.round(performance.now()))},1000);
setInterval(()=>{ // watchdog for silent links
  if(Link.ok&&!Link.demo&&Link.lastRx&&performance.now()-Link.lastRx>4500&&Link.type==="ws"){onLost("ไม่ได้รับสัญญาณจากรถ")}},1500);

/* ---------- demo car simulation ---------- */
function demoRx(line){
  const p=line.split(",");
  if(p[0]==="J"||p[0]==="T"){
    let l,r;
    if(p[0]==="J"){const x=+p[1],y=+p[2];l=y+x;r=y-x;const m=Math.max(Math.abs(l),Math.abs(r));if(m>100){l=l*100/m;r=r*100/m}}else{l=+p[1];r=+p[2]}
    const lim=demoTurbo?100:demoLimit;l=l*lim/100;r=r*lim/100;demoT=[l,r,l,r];
  }else if(p[0]==="X"){demoT=[0,0,0,0]}
  else if(p[0]==="P"){demoLimit=+p[1]}
  else if(p[0]==="B"){demoTurbo=p[1]==="1"}
  else if(p[0]==="M"){const i=+p[1];demoT=[0,0,0,0];demoT[i]=+p[3];setTimeout(()=>demoT=[0,0,0,0],900)}
}
setInterval(()=>{if(Link.demo){for(let i=0;i<4;i++)demoOut[i]+=(demoT[i]-demoOut[i])*.25;out=demoOut.map(v=>Math.round(v));carPower=demoTurbo?100:demoLimit}},40);

/* ---------- car render ---------- */
function drawBar(id,v,wy){
  const g=$("#"+id),b=g.querySelector(".bar"),h=Math.abs(v)/100*30;
  b.setAttribute("height",h.toFixed(1));
  if(v>=0)b.setAttribute("y",(wy-h).toFixed(1));else b.setAttribute("y",wy);
  b.setAttribute("fill",v>=0?"var(--a)":"var(--rev)");
  b.style.filter=`drop-shadow(0 0 ${6*Math.abs(v)/100}px ${v>=0?"var(--a)":"var(--rev)"})`;
}
function render(){
  const [fl,fr,bl,br]=out;
  drawBar("wFL",fl,83);drawBar("wFR",fr,83);drawBar("wBL",bl,237);drawBar("wBR",br,237);
  const avg=(Math.abs(fl)+Math.abs(fr)+Math.abs(bl)+Math.abs(br))/4;
  $("#spd").textContent=Math.round(avg);
  const fwd=(fl+fr+bl+br)/4;const ar=$("#arrow");
  ar.setAttribute("opacity",Math.min(.9,avg/70));ar.setAttribute("transform",fwd<-5?"rotate(180 100 132)":"");
  $("#tail").style.opacity=fwd<-5?1:.55;
  $("#ctag").textContent=Link.demo?"DEMO":(turbo?"TURBO":"LIVE");
  requestAnimationFrame(render);
}
requestAnimationFrame(render);

/* ---------- init ---------- */
applyTheme();
if(S.rgb)hue=190;
addEventListener("contextmenu",e=>e.preventDefault());
document.addEventListener("gesturestart",e=>e.preventDefault());
</script>
</body>
</html>

)THEPHTML";

// ---------------- มอเตอร์ ----------------
static void writeChannel(int ch, int v /* -1023..1023 */, bool brakeIfZero) {
  int a = 0, b = 0;
  if (v > 0)      a = v;
  else if (v < 0) b = -v;
  else if (brakeIfZero) { a = PWM_MAX; b = PWM_MAX; }   // IN1=IN2=HIGH -> เบรก
  PWM_WRITE(PIN_A[ch], ch * 2,     a);
  PWM_WRITE(PIN_B[ch], ch * 2 + 1, b);
}

static void driveWheel(int wheel, float pct /* -100..100 */, bool brakeIfZero) {
  int ch = cfg.map[wheel] & 3;
  if (fabsf(pct) < 0.5f) { writeChannel(ch, 0, brakeIfZero); return; }
  float mag = fabsf(pct);
  float duty = cfg.minPwm + (100.0f - cfg.minPwm) * mag / 100.0f;   // ข้ามช่วงที่มอเตอร์ไม่หมุน
  if (duty > 100) duty = 100;
  int v = (int)(duty * PWM_MAX / 100.0f);
  bool neg = pct < 0;
  if (cfg.inv[wheel]) neg = !neg;
  writeChannel(ch, neg ? -v : v, false);
}

static void stopAll(bool instant) {
  for (int i = 0; i < 4; i++) { target[i] = 0; if (instant) cur[i] = 0; }
}

// ผสมสัญญาณ: x = เลี้ยวขวา(+), y = เดินหน้า(+)   ค่า -100..100
static void setTank(float l, float r) {
  // trim: + = ลดกำลังซ้าย (รถเฉไปขวา) , - = ลดกำลังขวา
  if (cfg.trim > 0) l *= (1.0f - cfg.trim / 100.0f);
  else if (cfg.trim < 0) r *= (1.0f + cfg.trim / 100.0f);
  float lim = (turbo ? 100 : powerLimit) / 100.0f;
  l = constrain(l, -100.0f, 100.0f) * lim;
  r = constrain(r, -100.0f, 100.0f) * lim;
  target[0] = l; target[2] = l;     // ซ้าย  FL, BL
  target[1] = r; target[3] = r;     // ขวา  FR, BR
}

static void setArcade(float x, float y) {
  float l = y + x, r = y - x;
  float m = fmaxf(fabsf(l), fabsf(r));
  if (m > 100.0f) { l = l * 100.0f / m; r = r * 100.0f / m; }   // รักษาสัดส่วนการเลี้ยว
  setTank(l, r);
}

static void updateMotors(float dtMs) {
  uint32_t now = millis();
  if (testWheel >= 0) {
    if (now > testUntil) { testWheel = -1; stopAll(true); }
    else {
      for (int i = 0; i < 4; i++) driveWheel(i, i == testWheel ? (float)testPct : 0.0f, false);
      return;
    }
  }
  if (now - lastCmdMs > FAILSAFE_MS) stopAll(false);

  float stepUp   = cfg.rampMs <= 0 ? 1000.0f : 100.0f * dtMs / (float)cfg.rampMs;
  float stepDown = stepUp * 2.5f;                          // เบรกเร็วกว่าออกตัว
  for (int i = 0; i < 4; i++) {
    float t = target[i], c = cur[i];
    bool decel = fabsf(t) < fabsf(c) || (t * c < 0);
    float st = decel ? stepDown : stepUp;
    if (t > c) c = fminf(t, c + st); else c = fmaxf(t, c - st);
    cur[i] = c;
    driveWheel(i, c, cfg.brake);
  }
}

// ---------------- ส่งสถานะ ----------------
static void sendLine(const String& s) {
  ws.broadcastTXT(s.c_str());
#if ENABLE_BLE
  if (bleConnected && bleTx) {
    String m = s + "\n";
    // แบ่งส่งเป็นชิ้น <=20 ไบต์ เผื่อ MTU เล็ก
    for (size_t i = 0; i < m.length(); i += 20) {
      size_t n = min((size_t)20, m.length() - i);
      bleTx->setValue((uint8_t*)m.c_str() + i, n);
      bleTx->notify();
    }
  }
#endif
}

static void sendStatus() {
  char buf[64];
  snprintf(buf, sizeof(buf), "O,%d,%d,%d,%d,%d,%d",
           (int)roundf(cur[0]), (int)roundf(cur[1]), (int)roundf(cur[2]), (int)roundf(cur[3]),
           turbo ? 100 : powerLimit, turbo ? 1 : 0);
  sendLine(String(buf));
}

// ---------------- คำสั่ง ----------------
static void handleCommand(String s) {
  s.trim();
  if (s.length() == 0) return;
  const char* c = s.c_str();

  if (c[0] == 'J' && c[1] == ',') {
    int x = 0, y = 0;
    if (sscanf(c + 2, "%d,%d", &x, &y) == 2 && testWheel < 0) {
      lastCmdMs = millis();
      setArcade(constrain(x, -100, 100), constrain(y, -100, 100));
    }
  } else if (c[0] == 'T' && c[1] == ',') {
    int l = 0, r = 0;
    if (sscanf(c + 2, "%d,%d", &l, &r) == 2 && testWheel < 0) {
      lastCmdMs = millis();
      setTank(constrain(l, -100, 100), constrain(r, -100, 100));
    }
  } else if (c[0] == 'P' && c[1] == ',') {
    powerLimit = constrain(atoi(c + 2), 10, 100);
  } else if (c[0] == 'B' && c[1] == ',') {
    turbo = atoi(c + 2) != 0;
  } else if (c[0] == 'X' && (c[1] == 0)) {
    stopAll(true);
  } else if (strncmp(c, "M,", 2) == 0) {
    int i = 0, d = 1, p = 50;
    if (sscanf(c + 2, "%d,%d,%d", &i, &d, &p) == 3 && i >= 0 && i < 4) {
      stopAll(true);
      testWheel = i;
      testPct = constrain(p, 10, 100) * (d >= 0 ? 1 : -1);
      testUntil = millis() + 900;
    }
  } else if (strncmp(c, "CFG,", 4) == 0) {
    int v[12];
    if (sscanf(c + 4, "%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d",
               &v[0], &v[1], &v[2], &v[3], &v[4], &v[5], &v[6], &v[7], &v[8], &v[9], &v[10], &v[11]) == 12) {
      for (int i = 0; i < 4; i++) { cfg.inv[i] = v[i] != 0; cfg.map[i] = (uint8_t)constrain(v[4 + i], 0, 3); }
      cfg.minPwm = constrain(v[8], 0, 60);
      cfg.rampMs = constrain(v[9], 0, 1500);
      cfg.trim   = constrain(v[10], -30, 30);
      cfg.brake  = v[11] != 0;
    }
  } else if (strncmp(c, "PING,", 5) == 0) {
    sendLine(String("PONG,") + (c + 5));
  }
}

// ---------------- WebSocket ----------------
static void onWsEvent(uint8_t num, WStype_t type, uint8_t* payload, size_t length) {
  switch (type) {
    case WStype_DISCONNECTED:
      stopAll(true);
      break;
    case WStype_TEXT: {
      String s((const char*)payload, length);
      int start = 0;
      while (start < (int)s.length()) {          // รองรับหลายบรรทัด
        int nl = s.indexOf('\n', start);
        if (nl < 0) nl = s.length();
        handleCommand(s.substring(start, nl));
        start = nl + 1;
      }
      break;
    }
    default: break;
  }
}

// ---------------- BLE ----------------
#if ENABLE_BLE
#define NUS_SERVICE "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define NUS_RX      "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"   // มือถือเขียนเข้ามา
#define NUS_TX      "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"   // ESP32 แจ้งกลับ (notify)

class SrvCb : public BLEServerCallbacks {
  void onConnect(BLEServer*) override { bleConnected = true; bleBuf = ""; }
  void onDisconnect(BLEServer*) override {
    bleConnected = false;
    stopAll(true);
    BLEDevice::startAdvertising();
  }
};
class RxCb : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* ch) override {
    auto v = ch->getValue();
    String chunk(v.c_str());
    bleBuf += chunk;
    int nl;
    while ((nl = bleBuf.indexOf('\n')) >= 0) {
      String line = bleBuf.substring(0, nl);
      bleBuf = bleBuf.substring(nl + 1);
      handleCommand(line);
    }
    if (bleBuf.length() > 200) bleBuf = "";
  }
};

static void startBLE() {
  BLEDevice::init(BLE_NAME);
  BLEServer* srv = BLEDevice::createServer();
  srv->setCallbacks(new SrvCb());
  BLEService* svc = srv->createService(NUS_SERVICE);
  bleTx = svc->createCharacteristic(NUS_TX, BLECharacteristic::PROPERTY_NOTIFY);
  bleTx->addDescriptor(new BLE2902());
  BLECharacteristic* rx = svc->createCharacteristic(
      NUS_RX, BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  rx->setCallbacks(new RxCb());
  svc->start();
  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(NUS_SERVICE);
  adv->setScanResponse(true);
  adv->setMinPreferred(0x06);
  BLEDevice::startAdvertising();
}
#endif

// ---------------- setup / loop ----------------
void setup() {
  Serial.begin(115200);
  for (int i = 0; i < 4; i++) {
    PWM_ATTACH(PIN_A[i], i * 2);
    PWM_ATTACH(PIN_B[i], i * 2 + 1);
    PWM_WRITE(PIN_A[i], i * 2, 0);
    PWM_WRITE(PIN_B[i], i * 2 + 1, 0);
  }

  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS, 6, 0, 4);
  Serial.print("AP IP: "); Serial.println(WiFi.softAPIP());

  server.on("/", HTTP_GET, []() {
    server.sendHeader("Cache-Control", "no-cache");
    server.send_P(200, "text/html; charset=utf-8", INDEX_HTML);
  });
  server.on("/ping", HTTP_GET, []() { server.send(200, "text/plain", "THEP4WD"); });
  server.onNotFound([]() { server.sendHeader("Location", "/", true); server.send(302, "text/plain", ""); });
  server.begin();

  ws.begin();
  ws.onEvent(onWsEvent);
  ws.enableHeartbeat(1500, 800, 2);       // ตัดไคลเอนต์ที่ค้างเอง

#if ENABLE_BLE
  startBLE();
#endif
  lastCmdMs = millis();
  Serial.println("THEP 4WD ready");
}

void loop() {
  static uint32_t tMotor = 0, tStat = 0;
  server.handleClient();
  ws.loop();

  uint32_t now = millis();
  if (now - tMotor >= 5) {
    float dt = (float)(now - tMotor);
    tMotor = now;
    updateMotors(dt);
  }
  if (now - tStat >= 100) {
    tStat = now;
    sendStatus();
  }
}
