# THEP 4WD (ESP32 + L298N x2 + Bluetooth)

## ได้ APK
1. สร้าง repo ใหม่บน github.com แล้วอัปโหลด/push ไฟล์ทั้งหมดในโฟลเดอร์นี้
2. แท็บ **Actions** -> Build APK -> รอ ~3-5 นาที -> ดาวน์โหลด Artifact `THEP_4WD_Controller` (ได้ app-debug.apk)
3. ติดตั้งในมือถือ (อนุญาตติดตั้งจากแหล่งที่ไม่รู้จัก)

## ฮาร์ดแวร์
- แฟลช `firmware/THEP_4WD_Firmware_v3.ino` ด้วย Arduino IDE (บอร์ด ESP32 Dev Module, core 2.x หรือ 3.x)
- จับคู่ Bluetooth "THEP_4WD" ในมือถือก่อน แล้วเปิดแอป -> CONNECT
- ต่อสายตามตารางใน `firmware/WIRING.txt` และเข้าหน้า SETUP ทดสอบ/กลับทิศมอเตอร์ (ยกรถให้ล้อลอย)
