// THEP_4WD_Firmware_v3 - ESP32 (WROOM-32) + L298N x2
// App->ESP32: M,l,r | S | G | T,i | V,i,v     ESP32->App: T,l,r,mV | CFG,a,b,c,d,e | FS
#include <Arduino.h>
#include <BluetoothSerial.h>
#include <Preferences.h>
#if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
#error "Need ESP32 with Bluetooth Classic (WROOM-32 / DevKit V1)"
#endif
#define DEVICE_NAME "THEP_4WD"
#define LED_PIN 2
#define BAT_PIN -1
#define BAT_RATIO 4.03f
const uint8_t MP[4][3] = {{25,26,27},{33,32,4},{23,22,21},{13,18,19}};
const uint32_t PWM_FREQ = 1000;
const uint8_t PWM_BITS = 8;
const int MIN_PWM = 90;
const int MAX_PWM = 255;
const int RAMP_STEP = 8;
const uint32_t FAILSAFE_MS = 500;
const uint32_t TELE_MS = 200;
const int TEST_SPEED = 60;
const uint32_t TEST_MS = 1000;

BluetoothSerial SerialBT;
Preferences prefs;
uint8_t inv[4] = {0,0,0,0};
uint8_t swapLR = 0;
int tgtL = 0, tgtR = 0, curL = 0, curR = 0;
int testMotor = -1;
uint32_t testEnd = 0, lastCmd = 0, lastRamp = 0, lastTele = 0, lastLed = 0;
bool fsSent = false, hadClient = false, ledOn = false;
bool legacyMode = false;
int legSpeed = 50;
char legCmd = 'S';
char rx[48];
uint8_t rxLen = 0;

void pwmSetup(uint8_t i) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(MP[i][0], PWM_FREQ, PWM_BITS);
#else
  ledcSetup(i, PWM_FREQ, PWM_BITS);
  ledcAttachPin(MP[i][0], i);
#endif
}
void pwmWrite(uint8_t i, uint32_t duty) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(MP[i][0], duty);
#else
  ledcWrite(i, duty);
#endif
}
void driveMotor(uint8_t i, int v) {
  v = constrain(v, -100, 100);
  if (inv[i]) v = -v;
  if (v == 0) {
    digitalWrite(MP[i][1], LOW); digitalWrite(MP[i][2], LOW); pwmWrite(i, 0);
    return;
  }
  int duty = map(abs(v), 1, 100, MIN_PWM, MAX_PWM);
  digitalWrite(MP[i][1], v > 0 ? HIGH : LOW);
  digitalWrite(MP[i][2], v > 0 ? LOW : HIGH);
  pwmWrite(i, duty);
}
void applySides(int l, int r) {
  if (swapLR) { int t = l; l = r; r = t; }
  driveMotor(0, l); driveMotor(1, l); driveMotor(2, r); driveMotor(3, r);
}
void stopNow() { tgtL = tgtR = curL = curR = 0; testMotor = -1; applySides(0, 0); }
int approach(int c, int t, int s) {
  if (c < t) return min(c + s, t);
  if (c > t) return max(c - s, t);
  return c;
}
void loadCfg() {
  prefs.begin("thep", true);
  for (int i = 0; i < 4; i++) { char k[4] = {'i', char('0' + i), 0}; inv[i] = prefs.getUChar(k, 0); }
  swapLR = prefs.getUChar("sw", 0);
  prefs.end();
}
void saveCfg() {
  prefs.begin("thep", false);
  for (int i = 0; i < 4; i++) { char k[4] = {'i', char('0' + i), 0}; prefs.putUChar(k, inv[i]); }
  prefs.putUChar("sw", swapLR);
  prefs.end();
}
void sendCfg() { SerialBT.printf("CFG,%d,%d,%d,%d,%d\n", inv[0], inv[1], inv[2], inv[3], swapLR); }
int readBattMv() {
#if BAT_PIN >= 0
  uint32_t s = 0;
  for (int i = 0; i < 8; i++) s += analogReadMilliVolts(BAT_PIN);
  return (int)((s / 8) * BAT_RATIO);
#else
  return -1;
#endif
}
void legacyApply() {
  int s = legSpeed, a = s / 3, l = 0, r = 0;
  switch (legCmd) {
    case 'F': l = r = s; break;
    case 'B': l = r = -s; break;
    case 'L': l = -s; r = s; break;
    case 'R': l = s; r = -s; break;
    case 'G': l = a; r = s; break;
    case 'I': l = s; r = a; break;
    case 'H': l = -a; r = -s; break;
    case 'J': l = -s; r = -a; break;
  }
  tgtL = l; tgtR = r;
}
// รองรับโปรโตคอลเก่า: F B L R G I H J S และความเร็ว 0-9, q
bool legacyChar(char c) {
  if (testMotor >= 0) return false;
  if (c >= '0' && c <= '9') { legSpeed = (c - '0') * 10; legacyApply(); }
  else if (c == 'q') { legSpeed = 100; legacyApply(); }
  else if (c=='F'||c=='B'||c=='L'||c=='R'||c=='I'||c=='H'||c=='J') { legCmd = c; legacyApply(); }
  else return false;
  legacyMode = true; lastCmd = millis(); fsSent = false;
  return true;
}
void handle(const char* s) {
  legacyMode = false;
  lastCmd = millis();
  switch (s[0]) {
    case 'M': {
      int l, r;
      if (sscanf(s, "M,%d,%d", &l, &r) == 2) {
        fsSent = false;
        if (testMotor < 0) { tgtL = constrain(l, -100, 100); tgtR = constrain(r, -100, 100); }
      }
      break;
    }
    case 'S': stopNow(); break;
    case 'G': sendCfg(); break;
    case 'T': {
      int i;
      if (sscanf(s, "T,%d", &i) == 1 && i >= 0 && i < 4) {
        stopNow(); testMotor = i; testEnd = millis() + TEST_MS; driveMotor(i, TEST_SPEED);
      }
      break;
    }
    case 'V': {
      int i, v;
      if (sscanf(s, "V,%d,%d", &i, &v) == 2 && i >= 0 && i <= 4) {
        stopNow();
        if (i < 4) inv[i] = v ? 1 : 0; else swapLR = v ? 1 : 0;
        saveCfg(); sendCfg();
      }
      break;
    }
  }
}
void setup() {
  Serial.begin(115200);
  for (uint8_t i = 0; i < 4; i++) {
    pinMode(MP[i][1], OUTPUT); pinMode(MP[i][2], OUTPUT);
    digitalWrite(MP[i][1], LOW); digitalWrite(MP[i][2], LOW);
    pwmSetup(i); pwmWrite(i, 0);
  }
  pinMode(LED_PIN, OUTPUT);
  loadCfg();
  SerialBT.begin(DEVICE_NAME);
  Serial.println("THEP_4WD v3 ready");
}
void loop() {
  bool client = SerialBT.hasClient();
  if (client != hadClient) { hadClient = client; stopNow(); lastCmd = millis(); }
  while (SerialBT.available()) {
    char c = (char)SerialBT.read();
    if (rxLen == 0) {
      if (legacyChar(c)) continue;
      if (c == 'S') { stopNow(); legCmd = 'S'; lastCmd = millis(); continue; }
      if (c == 'G' && legacyMode) { legCmd = 'G'; legacyApply(); lastCmd = millis(); continue; }
    }
    if (c == '\n') { rx[rxLen] = 0; if (rxLen) handle(rx); rxLen = 0; }
    else if (c != '\r') { if (rxLen < sizeof(rx) - 1) rx[rxLen++] = c; else rxLen = 0; }
  }
  uint32_t now = millis();
  if (!client || now - lastCmd > (legacyMode ? 1500UL : FAILSAFE_MS)) {
    if (curL || curR || tgtL || tgtR || testMotor >= 0) {
      stopNow();
      if (client && !fsSent) { SerialBT.println("FS"); fsSent = true; }
    }
  }
  if (testMotor >= 0) {
    if ((int32_t)(now - testEnd) >= 0) stopNow();
  } else if (now - lastRamp >= 10) {
    lastRamp = now;
    curL = approach(curL, tgtL, RAMP_STEP);
    curR = approach(curR, tgtR, RAMP_STEP);
    applySides(curL, curR);
  }
  if (client && now - lastTele >= TELE_MS) {
    lastTele = now;
    SerialBT.printf("T,%d,%d,%d\n", curL, curR, readBattMv());
  }
  if (client) digitalWrite(LED_PIN, HIGH);
  else if (now - lastLed >= 400) { lastLed = now; ledOn = !ledOn; digitalWrite(LED_PIN, ledOn); }
}
