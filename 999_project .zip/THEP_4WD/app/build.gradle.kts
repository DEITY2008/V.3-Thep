plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.thep.controller"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.thep.controller"
        minSdk = 21
        targetSdk = 34
        versionCode = 4
        versionName = "3.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
}
