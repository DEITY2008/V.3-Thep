package com.thep.controller

import android.Manifest
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private val PRI = Color.parseColor("#FFC107")
private val SEC = Color.parseColor("#FF6D00")
private val GOOD = Color.parseColor("#00E676")
private val DNG = Color.parseColor("#FF3D00")
private val WARN = Color.parseColor("#FFD54F")

private fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

private fun lerpColor(a: Int, b: Int, t: Float): Int {
    val k = t.coerceIn(0f, 1f)
    val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt()
    val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt()
    val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
    return Color.rgb(r, g, bl)
}

private fun heat(p: Float): Int =
    if (p < 0.5f) lerpColor(PRI, SEC, p * 2f) else lerpColor(SEC, DNG, (p - 0.5f) * 2f)

// ---------------- พื้นหลังกริด (หน้าเมนู) ----------------
class GridBackground(ctx: Context) : View(ctx) {
    private val bg = Paint()
    private val g1 = Paint()
    private val g2 = Paint()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 2f }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    fun setRunning(on: Boolean) {
        if (on) {
            if (isAttachedToWindow && !anim.isStarted) anim.start()
        } else anim.cancel()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bg.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(Color.parseColor("#1C1407"), Color.parseColor("#0A0B0E"), Color.parseColor("#12161B")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        g1.shader = RadialGradient(w * 0.12f, h * 0.95f, max(1f, w * 0.5f), withAlpha(SEC, 80), 0, Shader.TileMode.CLAMP)
        g2.shader = RadialGradient(w * 0.92f, h * 0.05f, max(1f, w * 0.5f), withAlpha(PRI, 70), 0, Shader.TileMode.CLAMP)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (visibility == VISIBLE) anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, bg)
        c.drawRect(0f, 0f, w, h, g1)
        c.drawRect(0f, 0f, w, h, g2)
        val horizon = h * 0.5f
        for (i in 0 until 9) {
            val f = ((i + t) % 9f) / 9f
            val y = horizon + (h - horizon) * f * f
            line.color = withAlpha(PRI, (20 + 70 * f).toInt())
            c.drawLine(0f, y, w, y, line)
        }
        for (k in -12..12) {
            line.color = withAlpha(SEC, 38)
            c.drawLine(w / 2f + k * w * 0.02f, horizon, w / 2f + k * w * 0.10f, h, line)
        }
    }
}

// ---------------- ปุ่มนีออน ----------------
class NeonButton(
    ctx: Context,
    private val label: String,
    private val neon: Int,
    private val textSizeSp: Float = 14f
) : View(ctx) {
    var onClick: (() -> Unit)? = null
    private var down = false
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
        color = neon
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = 12f * d
        rect.set(m, m, w - m, h - m)
        val r = 8f * d
        fill.color = withAlpha(neon, if (down) 130 else 28)
        c.drawRoundRect(rect, r, r, fill)
        stroke.setShadowLayer(if (down) 28f * d else 12f * d, 0f, 0f, neon)
        c.drawRoundRect(rect, r, r, stroke)
        txt.textSize = textSizeSp * d
        c.drawText(label, w / 2f, h / 2f + txt.textSize / 3f, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true
                invalidate()
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            }
            MotionEvent.ACTION_UP -> {
                if (down) {
                    down = false
                    invalidate()
                    if (e.x in 0f..width.toFloat() && e.y in 0f..height.toFloat()) onClick?.invoke()
                }
            }
            MotionEvent.ACTION_CANCEL -> { down = false; invalidate() }
        }
        return true
    }
}

// ---------------- หน้าขับรถ: ซ้าย=คันเร่ง ขวา=พวงมาลัย ----------------
class DriveView(ctx: Context) : View(ctx) {
    @Volatile var outL = 0
    @Volatile var outR = 0
    @Volatile var lastTeleMs = System.currentTimeMillis()
    @Volatile var battMv = -1
    var estop = false
    var gear = 1
    var pivot = false
    var legacy = false
    var deviceName = "-"
    var onDisconnect: (() -> Unit)? = null
    var onSetup: (() -> Unit)? = null

    private var W = 1f
    private var H = 1f
    private var hu = 1f

    private var thrIn = 0f
    private var steerIn = 0f
    private var thrId = -1
    private var steerId = -1
    private var thrVis = 0f
    private var steerVis = 0f
    private var dispL = 0f
    private var dispR = 0f
    private var power = 0f
    private var avg = 0f

    private var lastNs = 0L
    private var clock = 0f
    private var gridT = 0f
    private var intro = 0f
    private var sparkAcc = 0f

    private val rnd = java.util.Random()
    private val NS = 36
    private val sx = FloatArray(NS)
    private val sy = FloatArray(NS)
    private val sv = FloatArray(NS)
    private val sl = FloatArray(NS)
    private val NP = 56
    private val px = FloatArray(NP)
    private val py = FloatArray(NP)
    private val pvx = FloatArray(NP)
    private val pvy = FloatArray(NP)
    private val pl = FloatArray(NP)

    private val bg = Paint()
    private val g1 = Paint()
    private val g2 = Paint()
    private val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val oval = RectF()

    private val rDisc = RectF()
    private val rSetup = RectF()
    private val rGear = Array(3) { RectF() }
    private val rMode = RectF()
    private val rEstop = RectF()

    init { setLayerType(LAYER_TYPE_HARDWARE, null) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        W = max(1f, w.toFloat()); H = max(1f, h.toFloat()); hu = H / 100f
        bg.shader = LinearGradient(
            0f, 0f, 0f, H,
            intArrayOf(Color.parseColor("#1C1407"), Color.parseColor("#0A0B0E"), Color.parseColor("#12161B")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        g1.shader = RadialGradient(W * 0.1f, H * 0.95f, W * 0.45f, withAlpha(SEC, 70), 0, Shader.TileMode.CLAMP)
        g2.shader = RadialGradient(W * 0.92f, H * 0.05f, W * 0.45f, withAlpha(PRI, 60), 0, Shader.TileMode.CLAMP)
        rDisc.set(W * 0.82f, H * 0.025f, W * 0.97f, H * 0.105f)
        rSetup.set(W * 0.66f, H * 0.025f, W * 0.80f, H * 0.105f)
        val gx0 = W * 0.32f
        val gap = W * 0.008f
        val bw = (W * 0.36f - 2 * gap) / 3f
        for (i in 0..2) rGear[i].set(gx0 + i * (bw + gap), H * 0.715f, gx0 + i * (bw + gap) + bw, H * 0.825f)
        rMode.set(W * 0.32f, H * 0.855f, W * 0.49f, H * 0.96f)
        rEstop.set(W * 0.50f, H * 0.855f, W * 0.68f, H * 0.96f)
        for (i in 0 until NS) {
            sx[i] = rnd.nextFloat() * W
            sy[i] = rnd.nextFloat() * H
            sv[i] = 0.6f + rnd.nextFloat() * 0.8f
            sl[i] = 0.5f + rnd.nextFloat() * 1.0f
        }
    }

    fun resetInputs() {
        thrIn = 0f; steerIn = 0f; thrId = -1; steerId = -1
        outL = 0; outR = 0
    }

    private fun haptic() { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

    private fun hitButtons(x: Float, y: Float): Boolean {
        if (rDisc.contains(x, y)) { haptic(); onDisconnect?.invoke(); return true }
        if (rSetup.contains(x, y)) { haptic(); onSetup?.invoke(); return true }
        for (i in 0..2) if (rGear[i].contains(x, y)) { gear = i; haptic(); return true }
        if (rMode.contains(x, y)) { pivot = !pivot; haptic(); return true }
        if (rEstop.contains(x, y)) {
            estop = !estop
            if (estop) { thrIn = 0f; steerIn = 0f }
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            return true
        }
        return false
    }

    private fun setThr(y: Float) {
        val top = H * 0.21f
        val bot = H * 0.93f
        val mid = (top + bot) / 2f
        thrIn = ((mid - y) / ((bot - top) / 2f)).coerceIn(-1f, 1f)
    }

    private fun setSteer(x: Float) {
        steerIn = ((x - W * 0.85f) / (W * 0.13f)).coerceIn(-1f, 1f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val id = e.getPointerId(i)
                val x = e.getX(i)
                val y = e.getY(i)
                if (!hitButtons(x, y)) {
                    if (x < W * 0.30f && y > H * 0.12f && thrId == -1) { thrId = id; setThr(y) }
                    else if (x > W * 0.70f && y > H * 0.12f && steerId == -1) { steerId = id; setSteer(x) }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    if (id == thrId) setThr(e.getY(i))
                    if (id == steerId) setSteer(e.getX(i))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val id = e.getPointerId(e.actionIndex)
                if (id == thrId) { thrId = -1; thrIn = 0f }
                if (id == steerId) { steerId = -1; steerIn = 0f }
            }
            MotionEvent.ACTION_CANCEL -> resetInputs()
        }
        return true
    }

    private fun expo(x: Float): Float {
        val a = abs(x)
        if (a < 0.05f) return 0f
        val n = (a - 0.05f) / 0.95f
        val v = 0.45f * n + 0.55f * n * n * n
        return if (x < 0f) -v else v
    }

    private fun update(dt: Float) {
        val cap = when (gear) { 0 -> 0.45f; 1 -> 0.75f; else -> 1f }
        val t = expo(thrIn) * cap
        val s = expo(steerIn) * max(0.55f, cap)
        var l: Float
        var r: Float
        if (pivot && abs(t) < 0.08f && abs(s) > 0.02f) {
            if (s > 0f) { l = s; r = 0f } else { l = 0f; r = -s }
        } else {
            l = t + s
            r = t - s
            val m = max(1f, max(abs(l), abs(r)))
            l /= m
            r /= m
        }
        if (estop) { l = 0f; r = 0f }
        outL = (l * 100f).roundToInt()
        outR = (r * 100f).roundToInt()

        val k = min(1f, dt * 12f)
        dispL += (l - dispL) * k
        dispR += (r - dispR) * k
        power = max(abs(dispL), abs(dispR)).coerceIn(0f, 1f)
        avg = (dispL + dispR) / 2f

        val kv = min(1f, dt * 16f)
        thrVis = if (thrId != -1) thrIn else thrVis - thrVis * kv
        steerVis = if (steerId != -1) steerIn else steerVis - steerVis * kv

        val dir = if (avg >= 0f) 1f else -1f
        gridT += dt * (0.25f + 2.2f * power) * dir
        for (i in 0 until NS) {
            sy[i] += dir * dt * H * (0.05f + 2.6f * power) * sv[i]
            val len = H * (0.02f + 0.28f * power) * sl[i]
            if (dir > 0f && sy[i] - len > H) { sy[i] = -len; sx[i] = rnd.nextFloat() * W }
            if (dir < 0f && sy[i] + len < 0f) { sy[i] = H + len; sx[i] = rnd.nextFloat() * W }
        }

        if (power > 0.35f) {
            sparkAcc += dt * power * 90f
            while (sparkAcc >= 1f) {
                sparkAcc -= 1f
                for (j in 0 until NP) {
                    if (pl[j] <= 0f) {
                        px[j] = W * 0.5f + (rnd.nextFloat() - 0.5f) * hu * 7f
                        py[j] = H * 0.40f + dir * hu * 14f
                        pvx[j] = (rnd.nextFloat() - 0.5f) * hu * 40f
                        pvy[j] = dir * H * (0.3f + rnd.nextFloat() * 0.9f)
                        pl[j] = 1f
                        break
                    }
                }
            }
        }
        for (j in 0 until NP) {
            if (pl[j] > 0f) {
                px[j] += pvx[j] * dt
                py[j] += pvy[j] * dt
                pl[j] -= dt * 1.7f
            }
        }
    }

    private inline fun glow(color: Int, width: Float, k: Float, draw: () -> Unit) {
        gp.color = withAlpha(color, (28 * k).toInt())
        gp.strokeWidth = width * 4.2f
        draw()
        gp.color = withAlpha(color, (70 * k).toInt())
        gp.strokeWidth = width * 2.2f
        draw()
        gp.color = withAlpha(color, (255 * k).toInt())
        gp.strokeWidth = width
        draw()
    }

    private fun text(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
        align: Paint.Align = Paint.Align.CENTER, mono: Boolean = false
    ) {
        tp.textSize = size
        tp.color = color
        tp.textAlign = align
        tp.typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT_BOLD
        tp.isFakeBoldText = true
        c.drawText(s, x, y, tp)
    }

    private fun button(c: Canvas, r: RectF, label: String, color: Int, active: Boolean, size: Float, filled: Boolean = false) {
        val rad = hu * 0.9f
        fp.color = withAlpha(color, if (active) 120 else if (filled) 70 else 24)
        c.drawRoundRect(r, rad, rad, fp)
        glow(color, hu * 0.4f, if (active) 1f else 0.65f) { c.drawRoundRect(r, rad, rad, gp) }
        text(c, label, r.centerX(), r.centerY() + size * 0.34f, size, if (active) Color.WHITE else color)
    }

    private fun wheelColor(v: Float): Int =
        if (abs(v) < 0.03f) Color.parseColor("#4A4F5A") else if (v > 0f) GOOD else SEC

    private fun wheel(c: Canvas, cx: Float, cy: Float, v: Float) {
        val ww = hu * 3.6f
        val wh = hu * 6.6f
        rect.set(cx - ww / 2f, cy - wh / 2f, cx + ww / 2f, cy + wh / 2f)
        val col = wheelColor(v)
        val a = abs(v)
        fp.color = withAlpha(col, (60 + 195 * a).toInt())
        c.drawRoundRect(rect, ww * 0.3f, ww * 0.3f, fp)
        glow(col, hu * 0.3f, 0.35f + 0.65f * a) { c.drawRoundRect(rect, ww * 0.3f, ww * 0.3f, gp) }
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((now - lastNs) / 1e9f).coerceIn(0f, 0.05f)
        lastNs = now
        clock += dt
        intro += dt
        update(dt)

        val col = heat(power)
        val cx = W * 0.5f
        val cy = H * 0.40f

        c.drawRect(0f, 0f, W, H, bg)
        c.drawRect(0f, 0f, W, H, g1)
        c.drawRect(0f, 0f, W, H, g2)

        val horizon = H * 0.5f
        gp.strokeWidth = 2f
        for (i in 0 until 9) {
            val f = ((((i + gridT) % 9f) + 9f) % 9f) / 9f
            val y = horizon + (H - horizon) * f * f
            gp.color = withAlpha(PRI, (18 + 60 * f).toInt())
            c.drawLine(0f, y, W, y, gp)
        }
        for (k in -12..12) {
            gp.color = withAlpha(SEC, 30)
            c.drawLine(W / 2f + k * W * 0.02f, horizon, W / 2f + k * W * 0.10f, H, gp)
        }

        val ea = (30 + 170 * power).toInt()
        fp.shader = LinearGradient(0f, 0f, W * 0.2f, 0f, withAlpha(col, ea), 0, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W * 0.2f, H, fp)
        fp.shader = LinearGradient(W, 0f, W * 0.8f, 0f, withAlpha(col, ea), 0, Shader.TileMode.CLAMP)
        c.drawRect(W * 0.8f, 0f, W, H, fp)
        fp.shader = null

        val dir = if (avg >= 0f) 1f else -1f
        gp.strokeWidth = hu * 0.35f
        for (i in 0 until NS) {
            val len = H * (0.02f + 0.28f * power) * sl[i]
            gp.color = withAlpha(col, (22 + 120 * power).toInt())
            c.drawLine(sx[i], sy[i], sx[i], sy[i] - dir * len, gp)
        }

        // คันเร่ง (ซ้าย)
        val tx = W * 0.15f
        val tTop = H * 0.21f
        val tBot = H * 0.93f
        val tMid = (tTop + tBot) / 2f
        val tHalf = (tBot - tTop) / 2f
        glow(PRI, hu * 0.5f, 0.55f) { c.drawLine(tx, tTop - hu * 2f, tx, tBot + hu * 2f, gp) }
        for (i in 0..8) {
            val y = tTop + (tBot - tTop) * i / 8f
            val big = (i == 0 || i == 4 || i == 8)
            gp.color = withAlpha(PRI, if (big) 200 else 90)
            gp.strokeWidth = hu * 0.35f
            c.drawLine(tx - hu * (if (big) 5f else 3f), y, tx + hu * (if (big) 5f else 3f), y, gp)
        }
        val tKnobY = tMid - thrVis * tHalf
        val tCol = if (thrVis >= 0f) heat(abs(thrVis)) else lerpColor(SEC, DNG, abs(thrVis))
        glow(tCol, hu * 1.4f, 0.9f) { c.drawLine(tx, tMid, tx, tKnobY, gp) }
        text(c, "THROTTLE", tx, H * 0.17f, hu * 3.4f, PRI)
        text(c, "FWD", tx + hu * 11f, tTop + hu * 1.2f, hu * 2.8f, GOOD)
        text(c, "REV", tx + hu * 11f, tBot + hu * 1.2f, hu * 2.8f, SEC)
        fp.color = Color.parseColor("#0E1014")
        c.drawCircle(tx, tKnobY, hu * 8.5f, fp)
        glow(tCol, hu * 0.6f, 1f) { c.drawCircle(tx, tKnobY, hu * 8.5f, gp) }
        glow(tCol, hu * 0.3f, 0.7f) { c.drawCircle(tx, tKnobY, hu * 4.8f, gp) }

        // พวงมาลัย (ขวา)
        val sCx = W * 0.85f
        val sHalf = W * 0.13f
        val sy0 = H * 0.64f
        glow(PRI, hu * 0.5f, 0.55f) { c.drawLine(sCx - sHalf - hu * 2f, sy0, sCx + sHalf + hu * 2f, sy0, gp) }
        for (i in 0..8) {
            val x = sCx - sHalf + 2f * sHalf * i / 8f
            val big = (i == 0 || i == 4 || i == 8)
            gp.color = withAlpha(PRI, if (big) 200 else 90)
            gp.strokeWidth = hu * 0.35f
            c.drawLine(x, sy0 - hu * (if (big) 5f else 3f), x, sy0 + hu * (if (big) 5f else 3f), gp)
        }
        val sKnobX = sCx + steerVis * sHalf
        val sCol = lerpColor(PRI, SEC, abs(steerVis))
        glow(sCol, hu * 1.4f, 0.9f) { c.drawLine(sCx, sy0, sKnobX, sy0, gp) }
        text(c, "STEER", sCx, H * 0.50f, hu * 3.4f, PRI)
        text(c, "L", sCx - sHalf, sy0 + hu * 12f, hu * 3.4f, SEC)
        text(c, "R", sCx + sHalf, sy0 + hu * 12f, hu * 3.4f, SEC)
        fp.color = Color.parseColor("#0E1014")
        c.drawCircle(sKnobX, sy0, hu * 8.5f, fp)
        glow(sCol, hu * 0.6f, 1f) { c.drawCircle(sKnobX, sy0, hu * 8.5f, gp) }
        glow(sCol, hu * 0.3f, 0.7f) { c.drawCircle(sKnobX, sy0, hu * 4.8f, gp) }

        // เกจกำลัง
        val R = H * 0.235f
        oval.set(cx - R, cy - R, cx + R, cy + R)
        val pulse = 0.5f + 0.5f * sin(clock * (3f + 6f * power))
        gp.strokeWidth = hu * 0.4f
        gp.color = withAlpha(col, (30 + 80 * pulse * (0.3f + power)).toInt())
        c.drawCircle(cx, cy, R * 1.17f, gp)
        glow(PRI, hu * 0.9f, 0.18f) { c.drawArc(oval, 135f, 270f, false, gp) }
        if (power > 0.005f) {
            glow(col, hu * 1.1f, 1f) { c.drawArc(oval, 135f, 270f * power, false, gp) }
        }
        for (i in 0..10) {
            val ang = (135f + 27f * i) * (PI.toFloat() / 180f)
            val on = i / 10f <= power + 0.001f
            gp.color = withAlpha(if (on) col else PRI, if (on) 255 else 70)
            gp.strokeWidth = hu * 0.4f
            c.drawLine(
                cx + cos(ang) * R * 1.07f, cy + sin(ang) * R * 1.07f,
                cx + cos(ang) * R * 1.14f, cy + sin(ang) * R * 1.14f, gp
            )
        }
        val pct = (power * 100f).roundToInt()
        text(c, "$pct", cx, cy + R * 0.93f, hu * 8.6f, Color.WHITE, mono = true)
        text(c, "POWER %", cx, cy + R * 0.93f + hu * 4.4f, hu * 2.7f, col)
        val state = when {
            estop -> "E-STOP"
            power < 0.03f -> "IDLE"
            dispL * dispR < -0.01f -> "SPIN"
            abs(dispL) < 0.03f || abs(dispR) < 0.03f -> "PIVOT"
            avg > 0f -> "FORWARD"
            else -> "REVERSE"
        }
        text(c, state, cx, cy - R * 0.78f, hu * 3.2f, if (estop) DNG else col)

        for (j in 0 until NP) {
            if (pl[j] > 0f) {
                fp.color = withAlpha(lerpColor(DNG, WARN, pl[j]), (255 * pl[j]).toInt())
                c.drawCircle(px[j], py[j], hu * (0.3f + 0.9f * pl[j]), fp)
            }
        }

        fp.shader = RadialGradient(cx, cy, hu * 22f, withAlpha(col, (30 + 110 * power).toInt()), 0, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, hu * 22f, fp)
        fp.shader = null

        // ตัวรถ
        val bl = hu * 26f
        val bw = hu * 13f
        rect.set(cx - bw / 2f, cy - bl / 2f, cx + bw / 2f, cy + bl / 2f)
        fp.color = Color.parseColor("#E60E1014")
        c.drawRoundRect(rect, hu * 3f, hu * 3f, fp)
        glow(PRI, hu * 0.5f, 0.9f) { c.drawRoundRect(rect, hu * 3f, hu * 3f, gp) }
        rect.set(cx - bw * 0.32f, cy - bl * 0.22f, cx + bw * 0.32f, cy + bl * 0.18f)
        fp.color = withAlpha(PRI, 38)
        c.drawRoundRect(rect, hu * 2f, hu * 2f, fp)
        gp.color = withAlpha(PRI, 120)
        gp.strokeWidth = hu * 0.3f
        c.drawRoundRect(rect, hu * 2f, hu * 2f, gp)
        val wx = bw / 2f + hu * 0.8f
        val wyF = cy - bl * 0.30f
        val wyR = cy + bl * 0.30f
        wheel(c, cx - wx, wyF, dispL)
        wheel(c, cx - wx, wyR, dispL)
        wheel(c, cx + wx, wyF, dispR)
        wheel(c, cx + wx, wyR, dispR)
        val fwd = max(0f, avg)
        fp.color = withAlpha(Color.parseColor("#FFFFFF"), (70 + 185 * fwd).toInt())
        c.drawCircle(cx - bw * 0.30f, cy - bl / 2f + hu * 1.6f, hu * 1.1f, fp)
        c.drawCircle(cx + bw * 0.30f, cy - bl / 2f + hu * 1.6f, hu * 1.1f, fp)
        val rev = if (avg < -0.03f) 1f else 0f
        fp.color = withAlpha(DNG, (90 + 165 * rev).toInt())
        c.drawCircle(cx - bw * 0.30f, cy + bl / 2f - hu * 1.6f, hu * 1.1f, fp)
        c.drawCircle(cx + bw * 0.30f, cy + bl / 2f - hu * 1.6f, hu * 1.1f, fp)

        // ปุ่ม
        val gearNames = arrayOf("ECO", "SPORT", "TURBO")
        val gearCols = intArrayOf(GOOD, PRI, DNG)
        for (i in 0..2) button(c, rGear[i], gearNames[i], gearCols[i], gear == i, hu * 3.6f)
        button(c, rMode, if (pivot) "TURN: PIVOT" else "TURN: SPIN", SEC, pivot, hu * 3.0f)
        button(c, rEstop, if (estop) "RELEASE" else "E-STOP", DNG, estop, hu * 3.6f, filled = true)
        button(c, rSetup, "SETUP", PRI, false, hu * 3.0f)
        button(c, rDisc, "DISCONNECT", DNG, false, hu * 2.8f)

        // แถบสถานะ
        val alive = legacy || System.currentTimeMillis() - lastTeleMs < 2000
        val blink = 0.5f + 0.5f * sin(clock * 6f)
        fp.color = withAlpha(if (alive) GOOD else DNG, (120 + 135 * (if (alive) 1f else blink)).toInt())
        c.drawCircle(W * 0.03f, H * 0.065f, hu * 1.6f, fp)
        val bat = if (battMv > 0) "  |  BAT " + String.format(Locale.US, "%.1fV", battMv / 1000f) else ""
        val st = if (alive) "$deviceName  |  LINK OK${if (legacy) " (LEGACY)" else ""}  |  L:${fmt(outL)}  R:${fmt(outR)}$bat"
        else "NO SIGNAL FROM ESP32  (ตรวจเฟิร์มแวร์ v3 / แบตเตอรี่)"
        text(c, st, W * 0.05f, H * 0.065f + hu * 1.3f, hu * 3.1f, if (alive) PRI else DNG, Paint.Align.LEFT)

        if (estop) {
            val fl = 0.5f + 0.5f * sin(clock * 9f)
            rect.set(hu, hu, W - hu, H - hu)
            gp.color = withAlpha(DNG, (90 + 150 * fl).toInt())
            gp.strokeWidth = hu * 1.4f
            c.drawRoundRect(rect, hu * 3f, hu * 3f, gp)
            text(c, "E-STOP", cx, H * 0.36f, hu * 15f, withAlpha(DNG, (40 + 40 * fl).toInt()))
        }

        if (intro < 1.3f) {
            val f = intro / 1.3f
            val y = H * f
            glow(PRI, hu * 0.5f, 1f - f) { c.drawLine(0f, y, W, y, gp) }
            text(c, "READY", cx, H * 0.5f, hu * 7f, withAlpha(PRI, (255 * (1f - f)).toInt()))
        }

        postInvalidateOnAnimation()
    }

    private fun fmt(v: Int): String = if (v > 0) "+$v" else "$v"
}

// ---------------- Activity หลัก ----------------
@SuppressLint("MissingPermission", "ClickableViewAccessibility")
class MainActivity : Activity() {

    companion object {
        private const val REQ_PERM = 1
        private const val REQ_BT_ON = 2
        private const val CAR_NAME = "THEP_4WD"
    }

    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val writing = AtomicBoolean(false)
    private val connGen = AtomicInteger(0)
    private val prefs by lazy { getSharedPreferences("thep", Context.MODE_PRIVATE) }

    private var adapter: BluetoothAdapter? = null
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var out: OutputStream? = null
    @Volatile private var connected = false
    @Volatile private var connecting = false
    @Volatile private var paused = false
    private var deviceName = "-"
    private var lastBack = 0L
    private var legacy = true
    private var lastSpd = ' '
    private var spdTick = 0

    private lateinit var root: FrameLayout
    private lateinit var gridBg: GridBackground
    private lateinit var content: FrameLayout
    private var listBox: LinearLayout? = null
    private var drive: DriveView? = null
    private var screen = 0

    private var testL = 0
    private var testR = 0
    private var testUntil = 0L
    private val cfg = IntArray(5)
    private val invBtns = arrayOfNulls<Button>(4)
    private var swapBtn: Button? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun glowText(text: String, size: Float, color: Int, glow: Int = color) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setShadowLayer(18f, 0f, 0f, glow)
    }

    private fun neonTitle(text: String, size: Float) = glowText(text, size, Color.WHITE, PRI).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        letterSpacing = 0.1f
        val wpx = paint.measureText(text) * 1.3f
        paint.shader = LinearGradient(0f, 0f, max(1f, wpx), 0f, PRI, SEC, Shader.TileMode.CLAMP)
    }

    private fun btn(text: String, size: Float, c: Int): Button = Button(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        isAllCaps = false
        stateListAnimator = null
        background = GradientDrawable().apply {
            setColor(withAlpha(c, 40))
            setStroke(dp(2), c)
            cornerRadius = dp(6).toFloat()
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        legacy = prefs.getBoolean("legacy", true)
        adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        root = FrameLayout(this)
        gridBg = GridBackground(this)
        root.addView(gridBg, FrameLayout.LayoutParams(-1, -1))
        content = FrameLayout(this)
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        showStart()
    }

    @Suppress("DEPRECATION")
    private fun hideBars(hide: Boolean) {
        window.decorView.systemUiVisibility = if (hide)
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        else View.SYSTEM_UI_FLAG_VISIBLE
    }

    private fun setScreen(v: View, id: Int, padded: Boolean = true) {
        screen = id
        hideBars(id == 2)
        val showGrid = id != 2
        gridBg.visibility = if (showGrid) View.VISIBLE else View.GONE
        gridBg.setRunning(showGrid)
        content.removeAllViews()
        if (padded) content.setPadding(dp(20), dp(8), dp(20), dp(8)) else content.setPadding(0, 0, 0, 0)
        content.addView(v, FrameLayout.LayoutParams(-1, -1))
    }

    private fun showStart() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        col.addView(neonTitle("THEP 4WD", 52f))
        col.addView(glowText("4 W D   R C   C O M M A N D   U N I T", 11f, PRI))

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val c = NeonButton(this, "CONNECT", PRI, 17f)
        c.onClick = { ensurePermissions { ensureBtOn { showDevices() } } }
        row.addView(c, LinearLayout.LayoutParams(dp(260), dp(92)))

        val lastAddr = prefs.getString("last_addr", null)
        if (lastAddr != null) {
            val lastName = prefs.getString("last_name", CAR_NAME) ?: CAR_NAME
            val q = NeonButton(this, "QUICK: $lastName", SEC, 15f)
            q.onClick = { ensurePermissions { ensureBtOn { quickConnect(lastAddr) } } }
            row.addView(q, LinearLayout.LayoutParams(dp(260), dp(92)))
        }
        col.addView(row, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
        val pb = btn(if (legacy) "โปรโตคอล: LEGACY (F/B/L/R) — กดเพื่อสลับเป็น V3" else "โปรโตคอล: V3 (M,l,r) — กดเพื่อสลับเป็น LEGACY", 12f, WARN)
        pb.setOnClickListener {
            legacy = !legacy
            prefs.edit().putBoolean("legacy", legacy).apply()
            showStart()
        }
        col.addView(pb, LinearLayout.LayoutParams(dp(420), dp(48)).apply { topMargin = dp(6) })
        col.addView(glowText("ครั้งแรก: จับคู่ THEP_4WD ใน Settings > Bluetooth ก่อน", 11f, Color.LTGRAY, SEC))
        setScreen(col, 0)
    }

    private fun quickConnect(addr: String) {
        val a = adapter ?: return
        if (!BluetoothAdapter.checkBluetoothAddress(addr)) { showDevices(); return }
        connect(a.getRemoteDevice(addr))
    }

    private fun showConnecting(name: String) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        col.addView(neonTitle("LINKING...", 40f))
        col.addView(glowText("กำลังเชื่อมต่อ $name", 15f, PRI))
        col.addView(glowText("ถ้ามีหน้าต่างขอจับคู่ (Pair) ขึ้นมา ให้กดยืนยัน", 11f, Color.LTGRAY, SEC),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        setScreen(col, 4)
    }

    private val found = LinkedHashMap<String, BluetoothDevice>()
    private val receiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == BluetoothDevice.ACTION_FOUND) {
                val d: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33)
                    i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                else
                    i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                if (d != null && !found.containsKey(d.address)) {
                    found[d.address] = d
                    refreshList()
                }
            }
        }
    }
    private var receiverOn = false

    private fun showDevices() {
        val a = adapter
        if (a == null) { toast("เครื่องนี้ไม่มี Bluetooth"); return }
        if (!a.isEnabled) { toast("กรุณาเปิด Bluetooth ก่อน"); return }
        found.clear()
        try { a.bondedDevices?.forEach { found[it.address] = it } } catch (_: Exception) {}

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(glowText("เลือกอุปกรณ์  →  $CAR_NAME", 20f, PRI))
        val lb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listBox = lb
        col.addView(ScrollView(this).apply { addView(lb) }, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this)
        val scan = btn("ค้นหาอุปกรณ์", 15f, PRI)
        val set = btn("ตั้งค่า Bluetooth", 15f, SEC)
        val back = btn("กลับ", 15f, Color.GRAY)
        scan.setOnClickListener { startScan() }
        set.setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (_: Exception) {}
        }
        back.setOnClickListener { stopScan(); showStart() }
        row.addView(scan, LinearLayout.LayoutParams(0, dp(56), 1f).apply { marginEnd = dp(8) })
        row.addView(set, LinearLayout.LayoutParams(0, dp(56), 1f).apply { marginEnd = dp(8) })
        row.addView(back, LinearLayout.LayoutParams(0, dp(56), 1f))
        col.addView(row)
        setScreen(col, 1)
        refreshList()
    }

    private fun refreshList() {
        val lb = listBox ?: return
        if (screen != 1) return
        lb.removeAllViews()
        if (found.isEmpty()) {
            lb.addView(glowText("ยังไม่พบอุปกรณ์ — กด \"ค้นหาอุปกรณ์\" หรือจับคู่ใน \"ตั้งค่า Bluetooth\"", 13f, Color.LTGRAY, SEC),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })
            return
        }
        val sorted = found.values.sortedByDescending { (it.name ?: "") == CAR_NAME }
        for (d in sorted) {
            val name = d.name ?: "(ไม่มีชื่อ)"
            val isCar = name == CAR_NAME
            val b = btn("$name\n${d.address}", 16f, if (isCar) SEC else Color.GRAY)
            b.setOnClickListener { stopScan(); connect(d) }
            lb.addView(b, LinearLayout.LayoutParams(-1, dp(72)).apply { topMargin = dp(6) })
        }
    }

    private fun startScan() {
        try {
            if (!receiverOn) {
                registerReceiver(receiver, IntentFilter(BluetoothDevice.ACTION_FOUND))
                receiverOn = true
            }
            adapter?.cancelDiscovery()
            if (adapter?.startDiscovery() == true) toast("กำลังค้นหา... (ประมาณ 12 วินาที)")
            else toast("ค้นหาไม่ได้ (Android 11 ลงไปต้องเปิด Location ด้วย)")
        } catch (e: Exception) {
            toast("ค้นหาไม่ได้: ${e.message}")
        }
    }

    private fun stopScan() {
        try { adapter?.cancelDiscovery() } catch (_: Exception) {}
        if (receiverOn) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            receiverOn = false
        }
    }

    private fun openSocket(d: BluetoothDevice): BluetoothSocket {
        try { adapter?.cancelDiscovery() } catch (_: Exception) {}
        val makers: List<() -> BluetoothSocket> = listOf(
            { d.createRfcommSocketToServiceRecord(SPP) },
            { d.createInsecureRfcommSocketToServiceRecord(SPP) },
            {
                d.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                    .invoke(d, 1) as BluetoothSocket
            }
        )
        var last: Exception? = null
        for (mk in makers) {
            var s: BluetoothSocket? = null
            try {
                s = mk()
                s.connect()
                return s
            } catch (e: Exception) {
                last = e
                try { s?.close() } catch (_: Exception) {}
                try { Thread.sleep(300) } catch (_: Exception) {}
            }
        }
        throw last ?: IOException("connect failed")
    }

    private fun connect(d: BluetoothDevice) {
        if (connecting) return
        connecting = true
        val name = try { d.name ?: d.address } catch (_: Exception) { d.address }
        showConnecting(name)
        Thread {
            try {
                closeSocket()
                val s = openSocket(d)
                val gen = connGen.incrementAndGet()
                socket = s
                out = s.outputStream
                deviceName = name
                connected = true
                connecting = false
                prefs.edit().putString("last_addr", d.address).putString("last_name", name).apply()
                ui.post {
                    drive = null
                    testUntil = 0L
                    lastSpd = ' '; spdTick = 0
                    showControl()
                    ui.removeCallbacks(tick)
                    ui.post(tick)
                    sendLine("G", true)
                }
                readLoop(s.inputStream, gen)
            } catch (e: Exception) {
                connecting = false
                connected = false
                ui.post {
                    toast("เชื่อมต่อไม่สำเร็จ: ตรวจว่ารถเปิดอยู่และจับคู่แล้ว")
                    showStart()
                }
            }
        }.start()
    }

    private fun readLoop(input: InputStream, gen: Int) {
        val buf = ByteArray(256)
        val sb = StringBuilder()
        try {
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                sb.append(String(buf, 0, n, Charsets.US_ASCII))
                while (true) {
                    val idx = sb.indexOf("\n")
                    if (idx < 0) break
                    val line = sb.substring(0, idx).trim()
                    sb.delete(0, idx + 1)
                    if (line.isNotEmpty()) handleLine(line)
                }
                if (sb.length > 512) sb.setLength(0)
            }
        } catch (_: Exception) {}
        if (gen == connGen.get() && connected) {
            connected = false
            ui.post { onLost() }
        }
    }

    private fun handleLine(line: String) {
        when {
            line.startsWith("T,") -> {
                val d = drive ?: return
                d.lastTeleMs = System.currentTimeMillis()
                val p = line.split(",")
                if (p.size >= 4) d.battMv = p[3].trim().toIntOrNull() ?: -1
            }
            line.startsWith("CFG,") -> {
                val parts = line.substring(4).split(",")
                ui.post {
                    for (i in 0 until min(5, parts.size)) cfg[i] = parts[i].trim().toIntOrNull() ?: 0
                    refreshSetupButtons()
                }
            }
            line.startsWith("FS") -> ui.post {
                if (screen == 2) toast("Failsafe: ESP32 หยุดรถเอง (สัญญาณขาดช่วง)")
            }
        }
    }

    private fun onLost() {
        toast("Bluetooth หลุด — รถหยุดอัตโนมัติแล้ว")
        ui.removeCallbacks(tick)
        drive?.resetInputs()
        testUntil = 0L
        closeSocket()
        showStart()
    }

    // ส่งคำสั่งขับ 20 ครั้ง/วินาที (เป็น heartbeat ด้วย)
    private val tick = object : Runnable {
        override fun run() {
            if (!connected) return
            var l = 0
            var r = 0
            if (!paused) {
                if (System.currentTimeMillis() < testUntil) {
                    l = testL; r = testR
                } else if (screen == 2) {
                    drive?.let { l = it.outL; r = it.outR }
                }
            }
            if (legacy) legacyTick(l, r) else sendLine("M,$l,$r", false)
            ui.postDelayed(this, 50)
        }
    }

    private fun sendLine(s: String, force: Boolean) {
        if (legacy) { if (s == "S") writeRaw("S", true); return }
        writeRaw(s + "\n", force)
    }

    // โหมด LEGACY: F B L R G I H J S + ความเร็ว 0-9,q (ใช้กับเฟิร์มแวร์รุ่นเก่า)
    private fun legacyTick(l: Int, r: Int) {
        val sum = (l + r) / 2
        val diff = (l - r) / 2
        val th = 12
        val cmd: Char = when {
            abs(sum) < th && abs(diff) < th -> 'S'
            abs(sum) < th -> if (diff > 0) 'R' else 'L'
            sum > 0 -> if (abs(diff) < th) 'F' else if (diff > 0) 'I' else 'G'
            else -> if (abs(diff) < th) 'B' else if (diff > 0) 'J' else 'H'
        }
        val sb = StringBuilder()
        if (cmd != 'S') {
            val p = max(abs(l), abs(r))
            val spd: Char = if (p >= 95) 'q' else ('0' + max(1, (p + 5) / 10)).coerceAtMost('9')
            spdTick++
            if (spd != lastSpd || spdTick >= 5) { sb.append(spd); lastSpd = spd; spdTick = 0 }
        }
        sb.append(cmd)
        writeRaw(sb.toString(), false)
    }

    private fun writeRaw(payload: String, force: Boolean) {
        val o = out ?: return
        if (!force && !writing.compareAndSet(false, true)) return
        if (force) writing.set(true)
        io.execute {
            try {
                o.write(payload.toByteArray(Charsets.US_ASCII))
                o.flush()
            } catch (e: Exception) {
                if (connected && o === out) {
                    connected = false
                    ui.post { onLost() }
                }
            } finally {
                writing.set(false)
            }
        }
    }

    private fun disconnect() {
        ui.removeCallbacks(tick)
        drive?.resetInputs()
        testUntil = 0L
        connected = false
        connGen.incrementAndGet()
        val s = socket
        val o = out
        socket = null
        out = null
        io.execute {
            try { o?.write("S\n".toByteArray()); o?.flush(); Thread.sleep(150) } catch (_: Exception) {}
            try { s?.close() } catch (_: Exception) {}
        }
        showStart()
    }

    private fun closeSocket() {
        val s = socket
        socket = null
        out = null
        connected = false
        try { s?.close() } catch (_: Exception) {}
    }

    private fun showControl() {
        val dv = drive ?: DriveView(this).also {
            it.deviceName = deviceName
            it.onDisconnect = { disconnect() }
            it.onSetup = {
                if (legacy) toast("SETUP ใช้ได้เฉพาะโหมด V3 (เปลี่ยนที่หน้าแรก)")
                else { drive?.resetInputs(); showSetup() }
            }
            drive = it
        }
        dv.legacy = legacy
        dv.resetInputs()
        setScreen(dv, 2, padded = false)
    }

    private fun runTest(l: Int, r: Int, ms: Long) {
        testL = l; testR = r
        testUntil = System.currentTimeMillis() + ms
    }

    private fun showSetup() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(glowText("SETUP  •  ทดสอบและตั้งทิศมอเตอร์", 18f, PRI))
        col.addView(glowText("ยกรถให้ล้อลอยก่อนทดสอบทุกครั้ง!", 12f, WARN))

        col.addView(glowText("1) ทดสอบทีละมอเตอร์ ถ้าล้อหมุนถอยหลังให้กดปุ่ม \"ทิศ\"", 13f, Color.WHITE),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val names = arrayOf(
            "M1 ซ้ายหน้า (L298N#1 ช่อง A)", "M2 ซ้ายหลัง (L298N#1 ช่อง B)",
            "M3 ขวาหน้า (L298N#2 ช่อง A)", "M4 ขวาหลัง (L298N#2 ช่อง B)"
        )
        for (i in 0..3) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val lab = glowText(names[i], 12f, PRI).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }
            val test = btn("ทดสอบ", 13f, GOOD)
            val inv = btn("", 13f, SEC)
            invBtns[i] = inv
            test.setOnClickListener { testUntil = 0L; sendLine("T,$i", true) }
            inv.setOnClickListener {
                val nv = 1 - cfg[i]
                cfg[i] = nv
                sendLine("V,$i,$nv", true)
                refreshSetupButtons()
            }
            row.addView(lab, LinearLayout.LayoutParams(0, -2, 1.3f))
            row.addView(test, LinearLayout.LayoutParams(0, dp(44), 0.7f).apply { marginEnd = dp(6) })
            row.addView(inv, LinearLayout.LayoutParams(0, dp(44), 0.8f))
            col.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        }

        col.addView(glowText("2) ทดสอบทั้งคัน (หมุน 1 วินาที)", 13f, Color.WHITE),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val r1 = LinearLayout(this)
        val bF = btn("เดินหน้า", 14f, GOOD)
        val bB = btn("ถอยหลัง", 14f, GOOD)
        val bL = btn("หมุนซ้าย", 14f, SEC)
        val bR = btn("หมุนขวา", 14f, SEC)
        val bS = btn("หยุด", 14f, DNG)
        bF.setOnClickListener { runTest(55, 55, 1000) }
        bB.setOnClickListener { runTest(-55, -55, 1000) }
        bL.setOnClickListener { runTest(-55, 55, 1000) }
        bR.setOnClickListener { runTest(55, -55, 1000) }
        bS.setOnClickListener { testUntil = 0L; sendLine("S", true) }
        for (b in arrayOf(bF, bB, bL, bR, bS)) {
            r1.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        }
        col.addView(r1)
        col.addView(glowText("เดินหน้า: ล้อทั้ง 4 ต้องหมุนไปข้างหน้า | หมุนซ้าย: ตัวรถต้องหมุนทวนเข็มนาฬิกา", 10f, Color.LTGRAY, PRI))

        col.addView(glowText("3) ถ้ากด \"หมุนซ้าย\" แล้วรถหมุนขวา ให้สลับซ้าย/ขวา", 13f, Color.WHITE),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val sw = btn("", 13f, WARN)
        swapBtn = sw
        sw.setOnClickListener {
            val nv = 1 - cfg[4]
            cfg[4] = nv
            sendLine("V,4,$nv", true)
            refreshSetupButtons()
        }
        col.addView(sw, LinearLayout.LayoutParams(-1, dp(44)))
        col.addView(glowText("ค่าที่ตั้งจะถูกบันทึกลง ESP32 ถาวร ปิดเครื่องแล้วค่าไม่หาย", 10f, Color.LTGRAY, PRI))

        val back = btn("กลับไปหน้าควบคุม", 15f, PRI)
        back.setOnClickListener { testUntil = 0L; sendLine("S", true); showControl() }
        col.addView(back, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(12) })

        setScreen(ScrollView(this).apply { addView(col) }, 3)
        refreshSetupButtons()
        sendLine("G", true)
    }

    private fun refreshSetupButtons() {
        if (screen != 3) return
        for (i in 0..3) invBtns[i]?.text = if (cfg[i] == 1) "ทิศ: กลับ" else "ทิศ: ปกติ"
        swapBtn?.text = if (cfg[4] == 1) "ซ้าย/ขวา: สลับแล้ว (กดเพื่อคืนค่า)" else "ซ้าย/ขวา: ปกติ (กดเพื่อสลับ)"
    }

    private var afterPerm: (() -> Unit)? = null
    private var afterBtOn: (() -> Unit)? = null

    private fun ensurePermissions(then: () -> Unit) {
        val need = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        else
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) then() else {
            afterPerm = then
            requestPermissions(missing.toTypedArray(), REQ_PERM)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERM) return
        val then = afterPerm
        afterPerm = null
        if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) then?.invoke()
        else toast("ต้องอนุญาต Permission Bluetooth ก่อนใช้งาน")
    }

    private fun ensureBtOn(then: () -> Unit) {
        val a = adapter
        if (a == null) { toast("เครื่องนี้ไม่มี Bluetooth"); return }
        if (a.isEnabled) { then(); return }
        afterBtOn = then
        try {
            startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_BT_ON)
        } catch (e: Exception) {
            afterBtOn = null
            toast("กรุณาเปิด Bluetooth ก่อน")
        }
    }

    @Deprecated("Platform API")
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_BT_ON) {
            val then = afterBtOn
            afterBtOn = null
            if (resultCode == RESULT_OK || adapter?.isEnabled == true) then?.invoke()
            else toast("ต้องเปิด Bluetooth ก่อนใช้งาน")
        }
    }

    @Deprecated("Platform API")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when (screen) {
            2 -> {
                val now = System.currentTimeMillis()
                if (now - lastBack < 2000) disconnect()
                else { lastBack = now; toast("กด Back อีกครั้งเพื่อตัดการเชื่อมต่อ") }
            }
            3 -> { testUntil = 0L; sendLine("S", true); showControl() }
            1 -> { stopScan(); showStart() }
            4 -> { }
            else -> super.onBackPressed()
        }
    }

    override fun onPause() {
        super.onPause()
        paused = true
        drive?.resetInputs()
        testUntil = 0L
        if (connected) sendLine("S", true)
    }

    override fun onResume() {
        super.onResume()
        paused = false
        if (screen == 2) hideBars(true)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && screen == 2) hideBars(true)
    }

    override fun onDestroy() {
        stopScan()
        ui.removeCallbacks(tick)
        connGen.incrementAndGet()
        val o = out
        val s = socket
        connected = false
        socket = null
        out = null
        io.execute {
            try { o?.write("S\n".toByteArray()); o?.flush() } catch (_: Exception) {}
            try { s?.close() } catch (_: Exception) {}
        }
        io.shutdown()
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
